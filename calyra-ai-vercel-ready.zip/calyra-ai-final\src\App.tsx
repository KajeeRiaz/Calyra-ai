import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import Browse from './pages/Browse'
import ValidationTools from './pages/ValidationTools'
import AdvancedTools from './pages/AdvancedTools'
import Pricing from './pages/Pricing'
import Navigation from './components/Navigation'

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/browse" element={<Browse />} />
            <Route path="/validation-tools" element={<ValidationTools />} />
            <Route path="/advanced-tools" element={<AdvancedTools />} />
            <Route path="/pricing" element={<Pricing />} />
          </Routes>
        </main>
      </div>
    </Router>
  )
}

export default App
