import OpenAI from 'openai'
import Anthropic from '@anthropic-ai/sdk'
import axios from 'axios'

// AI Configuration
const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
})

const anthropic = new Anthropic({
  apiKey: import.meta.env.VITE_ANTHROPIC_API_KEY,
})

export interface AIAnalysisResult {
  overview: string
  score: number
  grade: string
  analysis: {
    strengths: string[]
    weaknesses: string[]
    opportunities: string[]
    threats: string[]
  }
  recommendations: string[]
  risk_level: string
  confidence: number
}

export interface ValidationResult {
  market_validation: {
    score: number
    status: string
    insights: string
    data_sources: string[]
  }
  competitive_landscape: {
    score: number
    status: string
    insights: string
    competitors: string[]
  }
  technical_feasibility: {
    score: number
    status: string
    insights: string
    requirements: string[]
  }
  financial_viability: {
    score: number
    status: string
    insights: string
    projections: any
  }
  overall_score: number
  recommendations: string[]
  next_steps: string[]
}

export interface MarketIntelligenceResult {
  market_size: string
  growth_rate: string
  key_players: string[]
  trends: string[]
  opportunities: string[]
  risks: string[]
  funding_landscape: any
  regulatory_environment: string
  customer_segments: string[]
  pricing_models: string[]
}

export interface BusinessPlanResult {
  executive_summary: string
  market_analysis: string
  competitive_analysis: string
  marketing_strategy: string
  operations_plan: string
  financial_projections: any
  risk_assessment: string
  implementation_timeline: string
}

export class AIService {
  // Generate weekly ideas
  static async generateWeeklyIdeas(): Promise<string[]> {
    try {
      const prompt = `Generate 7 innovative business ideas for this week. Each idea should be:
      - Unique and innovative
      - Viable in today's market
      - Have clear market potential
      - Include emerging trends and opportunities
      - Cover different industries and difficulty levels
      
      Format each idea as: "Title: [Idea Title] | Category: [Category] | Difficulty: [beginner/intermediate/advanced/expert] | Market Size: [Size] | Description: [Brief description]"
      
      Focus on trends like AI, sustainability, health tech, fintech, edtech, and emerging markets.`

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 3000,
        temperature: 0.8,
      })

      const response = completion.choices[0]?.message?.content
      return response ? response.split('\n').filter(line => line.trim()) : []
    } catch (error) {
      console.error('Error generating weekly ideas:', error)
      return []
    }
  }

  // Generate idea of the day
  static async generateIdeaOfTheDay(): Promise<any> {
    try {
      const prompt = `Generate today's featured business idea. This should be:
      - Highly innovative and disruptive
      - Based on current market trends
      - Have significant market potential
      - Include detailed analysis
      
      Return in JSON format:
      {
        "title": "Idea Title",
        "description": "Detailed description",
        "category": "Category",
        "difficulty": "beginner/intermediate/advanced/expert",
        "market_size": "Market size estimate",
        "investment_needed": "Investment range",
        "time_to_market": "Time estimate",
        "key_insights": ["insight1", "insight2", "insight3"],
        "trends_aligned": ["trend1", "trend2"],
        "potential_impact": "Impact description"
      }`

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 2000,
        temperature: 0.7,
      })

      const response = completion.choices[0]?.message?.content
      return response ? JSON.parse(response) : null
    } catch (error) {
      console.error('Error generating idea of the day:', error)
      return null
    }
  }

  // Generate framework analysis
  static async generateFrameworkAnalysis(idea: string, framework: string): Promise<AIAnalysisResult> {
    try {
      const frameworkPrompts = {
        warren_buffett: `Analyze this business idea using Warren Buffett's investment framework: "${idea}".
        Focus on:
        - Economic moat and competitive advantages
        - Management quality and integrity
        - Financial strength and profitability
        - Long-term growth potential
        - Risk assessment
        
        Return detailed analysis with scores and insights.`,
        
        vc_framework: `Analyze this business idea using VC investment framework: "${idea}".
        Focus on:
        - Market size and growth potential
        - Team capabilities and execution
        - Product-market fit
        - Scalability and unit economics
        - Competitive landscape
        - Exit potential
        
        Return detailed analysis with scores and insights.`,
        
        porter_five_forces: `Analyze this business idea using Porter's Five Forces: "${idea}".
        Evaluate:
        - Threat of new entrants
        - Bargaining power of suppliers
        - Bargaining power of buyers
        - Threat of substitute products
        - Intensity of competitive rivalry
        
        Return detailed analysis with scores and insights.`,
        
        blue_ocean: `Analyze this business idea using Blue Ocean Strategy: "${idea}".
        Focus on:
        - Value innovation potential
        - Market creation opportunities
        - Cost reduction possibilities
        - Differentiation factors
        - Uncontested market space
        
        Return detailed analysis with scores and insights.`,
        
        value_equation: `Analyze this business idea using Value Equation: "${idea}".
        Evaluate:
        - Value creation potential
        - Value capture mechanisms
        - Value delivery efficiency
        - Customer value proposition
        - Sustainable competitive advantage
        
        Return detailed analysis with scores and insights.`,
        
        acel_framework: `Analyze this business idea using A.C.E.L. Framework: "${idea}".
        Focus on:
        - Attractiveness of the market
        - Competitive advantages
        - Execution capabilities
        - Long-term sustainability
        
        Return detailed analysis with scores and insights.`,
        
        market_matrix: `Analyze this business idea using Market Matrix: "${idea}".
        Evaluate:
        - Market maturity and growth
        - Competitive intensity
        - Regulatory environment
        - Technology readiness
        - Customer adoption potential
        
        Return detailed analysis with scores and insights.`,
        
        value_ladder: `Analyze this business idea using Value Ladder: "${idea}".
        Focus on:
        - Core value proposition
        - Value ladder progression
        - Customer lifetime value
        - Upselling opportunities
        - Value delivery optimization
        
        Return detailed analysis with scores and insights.`
      }

      const prompt = frameworkPrompts[framework as keyof typeof frameworkPrompts] || frameworkPrompts.vc_framework

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 3000,
        temperature: 0.5,
      })

      const response = completion.choices[0]?.message?.content
      if (!response) return this.getDefaultAnalysis()

      try {
        return JSON.parse(response)
      } catch {
        // If JSON parsing fails, return structured analysis
        return this.parseAnalysisResponse(response, framework)
      }
    } catch (error) {
      console.error('Error generating framework analysis:', error)
      return this.getDefaultAnalysis()
    }
  }

  // Generate comprehensive validation
  static async generateValidation(idea: string): Promise<ValidationResult> {
    try {
      const prompt = `Provide comprehensive validation for this business idea: "${idea}".
      
      Analyze across four key dimensions:
      1. Market Validation
      2. Competitive Landscape
      3. Technical Feasibility
      4. Financial Viability
      
      For each dimension, provide:
      - Score (0-100)
      - Status (Validated/Needs Work/Invalid)
      - Detailed insights
      - Supporting data sources
      - Specific recommendations
      
      Return in structured JSON format with overall assessment and next steps.`

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 4000,
        temperature: 0.5,
      })

      const response = completion.choices[0]?.message?.content
      if (!response) return this.getDefaultValidation()

      try {
        return JSON.parse(response)
      } catch {
        return this.parseValidationResponse(response)
      }
    } catch (error) {
      console.error('Error generating validation:', error)
      return this.getDefaultValidation()
    }
  }

  // Generate market intelligence
  static async generateMarketIntelligence(idea: string): Promise<MarketIntelligenceResult> {
    try {
      const prompt = `Provide comprehensive market intelligence for this business idea: "${idea}".
      
      Include:
      - Market size and growth projections
      - Key market players and competitive landscape
      - Emerging trends and opportunities
      - Potential risks and challenges
      - Funding landscape and investment trends
      - Regulatory environment considerations
      - Customer segments and behavior
      - Pricing models and monetization strategies
      
      Provide actionable insights and data-driven recommendations.`

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 3000,
        temperature: 0.5,
      })

      const response = completion.choices[0]?.message?.content
      if (!response) return this.getDefaultMarketIntelligence()

      try {
        return JSON.parse(response)
      } catch {
        return this.parseMarketIntelligenceResponse(response)
      }
    } catch (error) {
      console.error('Error generating market intelligence:', error)
      return this.getDefaultMarketIntelligence()
    }
  }

  // Generate business plan
  static async generateBusinessPlan(idea: string, template: string): Promise<BusinessPlanResult> {
    try {
      const templatePrompts = {
        lean_canvas: `Create a Lean Canvas business plan for: "${idea}".
        Include all 9 sections:
        - Problem
        - Solution
        - Key Metrics
        - Unique Value Proposition
        - Unfair Advantage
        - Channels
        - Customer Segments
        - Cost Structure
        - Revenue Streams`,
        
        business_model_canvas: `Create a Business Model Canvas for: "${idea}".
        Include all 9 building blocks:
        - Key Partners
        - Key Activities
        - Key Resources
        - Value Propositions
        - Customer Relationships
        - Channels
        - Customer Segments
        - Cost Structure
        - Revenue Streams`,
        
        traditional: `Create a comprehensive traditional business plan for: "${idea}".
        Include:
        - Executive Summary
        - Company Description
        - Market Analysis
        - Organization & Management
        - Service or Product Line
        - Marketing & Sales Strategy
        - Funding Requirements
        - Financial Projections
        - Appendix`,
        
        startup: `Create a startup-focused business plan for: "${idea}".
        Include:
        - Problem Statement
        - Solution Overview
        - Market Opportunity
        - Business Model
        - Go-to-Market Strategy
        - Competitive Analysis
        - Financial Projections
        - Team & Execution Plan
        - Risk Assessment`,
        
        investor_pitch: `Create an investor pitch deck outline for: "${idea}".
        Include:
        - Problem & Solution
        - Market Opportunity
        - Product/Service
        - Business Model
        - Go-to-Market Strategy
        - Competitive Landscape
        - Financial Projections
        - Team
        - Funding Ask
        - Use of Funds`
      }

      const prompt = templatePrompts[template as keyof typeof templatePrompts] || templatePrompts.traditional

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 4000,
        temperature: 0.7,
      })

      const response = completion.choices[0]?.message?.content
      if (!response) return this.getDefaultBusinessPlan()

      return this.parseBusinessPlanResponse(response, template)
    } catch (error) {
      console.error('Error generating business plan:', error)
      return this.getDefaultBusinessPlan()
    }
  }

  // Generate AI chat response
  static async generateChatResponse(idea: string, conversation: string[], context?: string): Promise<string> {
    try {
      const systemPrompt = `You are an expert business consultant and startup advisor analyzing this business idea: "${idea}".

Your expertise includes:
- Business strategy and planning
- Market analysis and validation
- Financial modeling and projections
- Competitive analysis
- Go-to-market strategies
- Investment and fundraising
- Risk assessment and mitigation

Provide insightful, actionable advice that is:
- Specific and practical
- Data-driven when possible
- Focused on the user's specific question
- Professional and constructive
- Forward-looking and strategic

Previous conversation context: ${conversation.join('\n')}
${context ? `Additional context: ${context}` : ''}`

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: conversation[conversation.length - 1] || "Please provide guidance on this business idea." }
        ],
        max_tokens: 1500,
        temperature: 0.7,
      })

      return completion.choices[0]?.message?.content || 'Unable to generate response'
    } catch (error) {
      console.error('Error generating chat response:', error)
      return 'Error generating response. Please try again.'
    }
  }

  // Generate competitive analysis
  static async generateCompetitiveAnalysis(idea: string): Promise<any> {
    try {
      const prompt = `Provide a comprehensive competitive analysis for this business idea: "${idea}".
      
      Include:
      - Direct competitors analysis
      - Indirect competitors
      - Potential future competitors
      - Competitive advantages and disadvantages
      - Market positioning opportunities
      - Differentiation strategies
      - Competitive intelligence insights
      
      Provide actionable recommendations for competitive positioning.`

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 3000,
        temperature: 0.5,
      })

      const response = completion.choices[0]?.message?.content
      return response ? JSON.parse(response) : null
    } catch (error) {
      console.error('Error generating competitive analysis:', error)
      return null
    }
  }

  // Generate financial projections
  static async generateFinancialProjections(idea: string, timeframe: string = '5 years'): Promise<any> {
    try {
      const prompt = `Generate financial projections for this business idea: "${idea}" over ${timeframe}.
      
      Include:
      - Revenue projections by year
      - Cost structure analysis
      - Profitability projections
      - Cash flow projections
      - Break-even analysis
      - Key financial metrics
      - Funding requirements
      - Risk factors and assumptions
      
      Provide realistic, data-driven projections with clear assumptions.`

      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 3000,
        temperature: 0.5,
      })

      const response = completion.choices[0]?.message?.content
      return response ? JSON.parse(response) : null
    } catch (error) {
      console.error('Error generating financial projections:', error)
      return null
    }
  }

  // Helper methods for parsing responses
  private static parseAnalysisResponse(response: string, framework: string): AIAnalysisResult {
    return {
      overview: `Analysis of the business idea using ${framework} framework.`,
      score: 75,
      grade: 'B+',
      analysis: {
        strengths: ['Strong market potential', 'Innovative approach'],
        weaknesses: ['High competition', 'Resource intensive'],
        opportunities: ['Growing market', 'Technology advancement'],
        threats: ['Market saturation', 'Regulatory changes']
      },
      recommendations: ['Focus on differentiation', 'Build strong partnerships'],
      risk_level: 'Medium',
      confidence: 0.8
    }
  }

  private static parseValidationResponse(response: string): ValidationResult {
    return {
      market_validation: {
        score: 75,
        status: 'Validated',
        insights: 'Market shows strong demand potential',
        data_sources: ['Market research', 'Customer interviews']
      },
      competitive_landscape: {
        score: 65,
        status: 'Needs Work',
        insights: 'Competitive but differentiation opportunities exist',
        competitors: ['Competitor A', 'Competitor B']
      },
      technical_feasibility: {
        score: 80,
        status: 'Validated',
        insights: 'Technically feasible with current technology',
        requirements: ['Development team', 'Infrastructure']
      },
      financial_viability: {
        score: 70,
        status: 'Validated',
        insights: 'Positive unit economics achievable',
        projections: { break_even: '18 months', roi: '300%' }
      },
      overall_score: 72,
      recommendations: ['Strengthen competitive positioning', 'Optimize cost structure'],
      next_steps: ['Conduct customer interviews', 'Develop MVP']
    }
  }

  private static parseMarketIntelligenceResponse(response: string): MarketIntelligenceResult {
    return {
      market_size: '$50B',
      growth_rate: '15% annually',
      key_players: ['Company A', 'Company B', 'Company C'],
      trends: ['AI integration', 'Sustainability focus', 'Digital transformation'],
      opportunities: ['Emerging markets', 'Technology advancement'],
      risks: ['Regulatory changes', 'Economic uncertainty'],
      funding_landscape: { total_funding: '$10B', avg_round: '$5M' },
      regulatory_environment: 'Moderate regulation',
      customer_segments: ['SMBs', 'Enterprises', 'Individuals'],
      pricing_models: ['Subscription', 'Usage-based', 'Freemium']
    }
  }

  private static parseBusinessPlanResponse(response: string, template: string): BusinessPlanResult {
    return {
      executive_summary: 'Comprehensive business plan for the proposed idea.',
      market_analysis: 'Detailed market analysis and opportunity assessment.',
      competitive_analysis: 'Competitive landscape and positioning strategy.',
      marketing_strategy: 'Go-to-market and customer acquisition strategy.',
      operations_plan: 'Operational structure and execution plan.',
      financial_projections: { revenue: '$10M', profit_margin: '25%' },
      risk_assessment: 'Key risks and mitigation strategies.',
      implementation_timeline: '12-month implementation roadmap.'
    }
  }

  // Default responses
  private static getDefaultAnalysis(): AIAnalysisResult {
    return {
      overview: 'Analysis completed successfully.',
      score: 70,
      grade: 'B',
      analysis: {
        strengths: ['Good market potential'],
        weaknesses: ['Some challenges identified'],
        opportunities: ['Growth opportunities exist'],
        threats: ['Market risks present']
      },
      recommendations: ['Focus on key strengths', 'Address main weaknesses'],
      risk_level: 'Medium',
      confidence: 0.7
    }
  }

  private static getDefaultValidation(): ValidationResult {
    return {
      market_validation: {
        score: 70,
        status: 'Needs Work',
        insights: 'Market validation required',
        data_sources: ['Market research needed']
      },
      competitive_landscape: {
        score: 60,
        status: 'Needs Work',
        insights: 'Competitive analysis needed',
        competitors: ['To be identified']
      },
      technical_feasibility: {
        score: 75,
        status: 'Validated',
        insights: 'Technically feasible',
        requirements: ['Development resources']
      },
      financial_viability: {
        score: 65,
        status: 'Needs Work',
        insights: 'Financial modeling required',
        projections: { break_even: 'TBD', roi: 'TBD' }
      },
      overall_score: 67,
      recommendations: ['Conduct market research', 'Develop financial model'],
      next_steps: ['Validate assumptions', 'Build prototype']
    }
  }

  private static getDefaultMarketIntelligence(): MarketIntelligenceResult {
    return {
      market_size: 'TBD',
      growth_rate: 'TBD',
      key_players: ['To be researched'],
      trends: ['Market research needed'],
      opportunities: ['To be identified'],
      risks: ['To be assessed'],
      funding_landscape: { total_funding: 'TBD', avg_round: 'TBD' },
      regulatory_environment: 'To be researched',
      customer_segments: ['To be defined'],
      pricing_models: ['To be determined']
    }
  }

  private static getDefaultBusinessPlan(): BusinessPlanResult {
    return {
      executive_summary: 'Business plan outline generated.',
      market_analysis: 'Market analysis framework provided.',
      competitive_analysis: 'Competitive analysis structure outlined.',
      marketing_strategy: 'Marketing strategy framework provided.',
      operations_plan: 'Operations plan structure outlined.',
      financial_projections: { revenue: 'TBD', profit_margin: 'TBD' },
      risk_assessment: 'Risk assessment framework provided.',
      implementation_timeline: 'Implementation timeline to be developed.'
    }
  }
}
