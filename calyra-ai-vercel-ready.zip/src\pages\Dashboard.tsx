import { useState, useEffect } from 'react'
import { useAuthContext } from '../contexts/AuthContext'
import { supabase } from '../lib/supabase'
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  DollarSign, 
  Activity, 
  Clock, 
  Star,
  FileText,
  MessageSquare,
  Target
} from 'lucide-react'

interface DashboardStats {
  totalIdeas: number
  totalAnalyses: number
  totalValidations: number
  totalChats: number
  subscriptionUsage: number
  subscriptionLimit: number
}

interface RecentActivity {
  id: string
  type: 'idea' | 'analysis' | 'validation' | 'chat'
  title: string
  description: string
  timestamp: string
}

export const Dashboard = () => {
  const { user } = useAuthContext()
  const [stats, setStats] = useState<DashboardStats>({
    totalIdeas: 0,
    totalAnalyses: 0,
    totalValidations: 0,
    totalChats: 0,
    subscriptionUsage: 0,
    subscriptionLimit: 100
  })
  const [recentActivities, setRecentActivities] = useState<RecentActivity[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (user) {
      loadDashboardData()
    }
  }, [user])

  const loadDashboardData = async () => {
    try {
      setLoading(true)
      
      // Load user's ideas
      const { data: ideas } = await supabase
        .from('ideas')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })

      // Load user's analyses
      const { data: analyses } = await supabase
        .from('analyses')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })

      // Load user's validations
      const { data: validations } = await supabase
        .from('validations')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })

      // Load user's chat messages
      const { data: chats } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })

      setStats({
        totalIdeas: ideas?.length || 0,
        totalAnalyses: analyses?.length || 0,
        totalValidations: validations?.length || 0,
        totalChats: chats?.length || 0,
        subscriptionUsage: (ideas?.length || 0) + (analyses?.length || 0) + (validations?.length || 0),
        subscriptionLimit: getSubscriptionLimit()
      })

      // Create recent activities
      const activities: RecentActivity[] = []
      
      ideas?.slice(0, 3).forEach(idea => {
        activities.push({
          id: idea.id,
          type: 'idea',
          title: 'New Idea Created',
          description: idea.title,
          timestamp: idea.created_at
        })
      })

      analyses?.slice(0, 3).forEach(analysis => {
        activities.push({
          id: analysis.id,
          type: 'analysis',
          title: 'Framework Analysis',
          description: `${analysis.framework_type} analysis completed`,
          timestamp: analysis.created_at
        })
      })

      validations?.slice(0, 3).forEach(validation => {
        activities.push({
          id: validation.id,
          type: 'validation',
          title: 'Idea Validation',
          description: `Validation score: ${validation.overall_score}/100`,
          timestamp: validation.created_at
        })
      })

      // Sort by timestamp and take top 5
      activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      setRecentActivities(activities.slice(0, 5))

    } catch (error) {
      console.error('Error loading dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  const getSubscriptionLimit = () => {
    switch (user?.subscription_tier) {
      case 'free': return 10
      case 'core': return 100
      case 'growth': return 1000
      case 'enterprise': return 10000
      default: return 10
    }
  }

  const getUsagePercentage = () => {
    return Math.min((stats.subscriptionUsage / stats.subscriptionLimit) * 100, 100)
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'idea': return <FileText size={16} />
      case 'analysis': return <BarChart3 size={16} />
      case 'validation': return <Target size={16} />
      case 'chat': return <MessageSquare size={16} />
      default: return <Activity size={16} />
    }
  }

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'idea': return 'text-blue-600 bg-blue-100'
      case 'analysis': return 'text-purple-600 bg-purple-100'
      case 'validation': return 'text-green-600 bg-green-100'
      case 'chat': return 'text-orange-600 bg-orange-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-8"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-white p-6 rounded-lg shadow">
                <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
                <div className="h-8 bg-gray-200 rounded w-1/3"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-2">
          Welcome back, {user?.full_name || user?.email}
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <FileText className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Ideas</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalIdeas}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 rounded-lg">
              <BarChart3 className="h-6 w-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Analyses</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalAnalyses}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <Target className="h-6 w-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Validations</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalValidations}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="p-2 bg-orange-100 rounded-lg">
              <MessageSquare className="h-6 w-6 text-orange-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">AI Chats</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalChats}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Subscription Usage */}
        <div className="lg:col-span-2">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Subscription Usage</h3>
            <div className="mb-4">
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span>Usage</span>
                <span>{stats.subscriptionUsage} / {stats.subscriptionLimit}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${getUsagePercentage()}%` }}
                ></div>
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">
                {user?.subscription_tier?.charAt(0).toUpperCase() + user?.subscription_tier?.slice(1)} Plan
              </span>
              <span className="text-gray-900 font-medium">
                {Math.round(getUsagePercentage())}% used
              </span>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <button className="w-full text-left p-3 rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors">
              <div className="flex items-center">
                <FileText className="h-5 w-5 text-blue-600 mr-3" />
                <span className="text-sm font-medium text-gray-900">Create New Idea</span>
              </div>
            </button>
            <button className="w-full text-left p-3 rounded-lg border border-gray-200 hover:border-purple-300 hover:bg-purple-50 transition-colors">
              <div className="flex items-center">
                <BarChart3 className="h-5 w-5 text-purple-600 mr-3" />
                <span className="text-sm font-medium text-gray-900">Run Analysis</span>
              </div>
            </button>
            <button className="w-full text-left p-3 rounded-lg border border-gray-200 hover:border-green-300 hover:bg-green-50 transition-colors">
              <div className="flex items-center">
                <Target className="h-5 w-5 text-green-600 mr-3" />
                <span className="text-sm font-medium text-gray-900">Validate Idea</span>
              </div>
            </button>
            <button className="w-full text-left p-3 rounded-lg border border-gray-200 hover:border-orange-300 hover:bg-orange-50 transition-colors">
              <div className="flex items-center">
                <MessageSquare className="h-5 w-5 text-orange-600 mr-3" />
                <span className="text-sm font-medium text-gray-900">Start AI Chat</span>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="mt-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
          {recentActivities.length > 0 ? (
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-center space-x-4">
                  <div className={`p-2 rounded-lg ${getActivityColor(activity.type)}`}>
                    {getActivityIcon(activity.type)}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">{activity.title}</p>
                    <p className="text-sm text-gray-600">{activity.description}</p>
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-1" />
                    {new Date(activity.timestamp).toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8">No recent activity</p>
          )}
        </div>
      </div>
    </div>
  )
}

