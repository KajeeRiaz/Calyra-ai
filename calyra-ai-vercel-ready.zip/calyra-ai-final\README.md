# Calyra.ai - AI-Powered Business Intelligence Platform

## 🚀 Overview

Calyra.ai is a comprehensive AI-powered business intelligence platform that helps entrepreneurs discover, validate, and develop startup ideas using institutional-grade analysis.

## ✨ Key Features

### 🧠 Advanced Intelligence Tools
- **VC-Grade Idea Builder**: Generate business plans, financial models, and pitch decks
- **Expert Framework Analysis**: Warren Buffett, VC, Porter's Five Forces, Blue Ocean Strategy
- **AI Chat per Idea**: Interactive AI-powered discussions about your ideas
- **Comprehensive Validation**: Multi-category validation with expert scoring

### 📊 Professional Analysis
- **Market Intelligence**: Advanced competitive analysis and market insights
- **Investment Readiness**: Prepare for VC meetings and funding rounds
- **Strategic Planning**: Go-to-market strategies and execution plans

### 💼 Enterprise Features
- **White-Label Solutions**: Custom branding and integration options
- **API Access**: Programmatic access to all features
- **Team Collaboration**: Multi-user support and shared workspaces

## 🛠️ Tech Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **Routing**: React Router DOM
- **Icons**: Lucide React
- **Build Tool**: Vite
- **Deployment**: Vercel-ready

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation
```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

### Environment Variables
Create a `.env` file in the root directory:
```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_OPENAI_API_KEY=your_openai_api_key
```

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── Navigation.tsx
│   ├── IdeaBuilderModal.tsx
│   ├── FrameworkAnalysis.tsx
│   ├── IdeaChatModal.tsx
│   └── ValidationModal.tsx
├── pages/              # Page components
│   ├── Home.tsx
│   ├── Browse.tsx
│   ├── AdvancedTools.tsx
│   ├── ValidationTools.tsx
│   └── Pricing.tsx
├── App.tsx             # Main app component
├── main.tsx           # Entry point
└── index.css          # Global styles
```

## 🎯 Features in Detail

### VC-Grade Idea Builder
- Business Plan Generation
- Financial Model Creation
- Pitch Deck Development
- Market Analysis Reports
- Go-to-Market Strategy
- Competitive Analysis

### Expert Framework Analysis
- Warren Buffett's Investment Framework
- VC Investment Criteria
- Porter's Five Forces
- Blue Ocean Strategy
- Market Matrix Analysis
- Value Ladder Assessment

### AI Chat per Idea
- Interactive AI discussions
- Context-aware responses
- Idea refinement suggestions
- Market opportunity exploration

### Comprehensive Validation
- Market validation scoring
- Competitive landscape analysis
- Risk assessment
- Investment readiness evaluation

## 💰 Pricing Plans

### Calyra Core ($199/year)
- Daily validated startup ideas
- Basic validation tools
- Community access
- Email support

### Calyra Growth ($1,499/year)
- Everything in Core
- VC-Grade Builder (6 templates)
- Expert Framework Analysis
- AI Chat per Idea
- Advanced validation frameworks
- Priority support

### Calyra Enterprise (Custom)
- Everything in Growth
- White-label solutions
- API access
- Dedicated account manager
- Custom integrations

## 🚀 Deployment

### Vercel (Recommended)
1. Push code to GitHub
2. Connect repository to Vercel
3. Deploy automatically

### Netlify
1. Build the project: `npm run build`
2. Deploy the `dist` folder

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

This project is proprietary software. All rights reserved.

## 🆘 Support

For support, email support@calyra.ai or visit our documentation.

---

**Built with ❤️ for entrepreneurs worldwide**
