import { useState, useEffect } from 'react'
import { useAuthContext } from '../contexts/AuthContext'
import { PaymentService, PAYMENT_PLANS } from '../lib/payment'
import { CreditCard, Calendar, Download, ArrowUpRight, Check } from 'lucide-react'
import toast from 'react-hot-toast'

interface PaymentHistory {
  id: string
  amount: number
  currency: string
  status: string
  date: string
  description: string
}

export const Billing = () => {
  const { user } = useAuthContext()
  const [loading, setLoading] = useState(false)
  const [paymentHistory, setPaymentHistory] = useState<PaymentHistory[]>([])
  const [currentPlan, setCurrentPlan] = useState<any>(null)

  useEffect(() => {
    loadBillingData()
  }, [user])

  const loadBillingData = async () => {
    try {
      setLoading(true)
      
      // Load current plan
      const plan = PAYMENT_PLANS.find(p => p.id === `calyra-${user?.subscription_tier}`)
      setCurrentPlan(plan)

      // Mock payment history - in real app, this would come from Paystack API
      const mockHistory: PaymentHistory[] = [
        {
          id: '1',
          amount: 1499,
          currency: 'USD',
          status: 'completed',
          date: '2024-01-15',
          description: 'Calyra Growth - Annual Subscription'
        },
        {
          id: '2',
          amount: 199,
          currency: 'USD',
          status: 'completed',
          date: '2023-12-15',
          description: 'Calyra Core - Annual Subscription'
        }
      ]
      setPaymentHistory(mockHistory)
    } catch (error) {
      console.error('Error loading billing data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleUpgrade = async (planId: string) => {
    try {
      setLoading(true)
      
      const result = await PaymentService.initializePayment(
        planId,
        user?.email || '',
        'USD'
      )

      if (result?.data?.authorization_url) {
        window.location.href = result.data.authorization_url
      } else {
        toast.error('Failed to initialize payment')
      }
    } catch (error) {
      console.error('Error upgrading plan:', error)
      toast.error('Failed to upgrade plan')
    } finally {
      setLoading(false)
    }
  }

  const handleCancelSubscription = async () => {
    if (!confirm('Are you sure you want to cancel your subscription? You will lose access to premium features at the end of your billing period.')) {
      return
    }

    try {
      setLoading(true)
      // In real app, this would call Paystack API to cancel subscription
      toast.success('Subscription cancelled successfully')
    } catch (error) {
      console.error('Error cancelling subscription:', error)
      toast.error('Failed to cancel subscription')
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100'
      case 'pending': return 'text-yellow-600 bg-yellow-100'
      case 'failed': return 'text-red-600 bg-red-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-8"></div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="bg-white p-6 rounded-lg shadow">
                <div className="h-4 bg-gray-200 rounded w-1/3 mb-4"></div>
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="h-16 bg-gray-200 rounded"></div>
                  ))}
                </div>
              </div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
              <div className="h-32 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Billing & Subscription</h1>
        <p className="text-gray-600 mt-2">Manage your subscription and payment history</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Payment History */}
        <div className="lg:col-span-2">
          <div className="bg-white p-6 rounded-lg shadow">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Payment History</h2>
              <button className="flex items-center text-sm text-blue-600 hover:text-blue-700">
                <Download size={16} className="mr-1" />
                Export
              </button>
            </div>

            {paymentHistory.length > 0 ? (
              <div className="space-y-4">
                {paymentHistory.map((payment) => (
                  <div key={payment.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <CreditCard className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">{payment.description}</p>
                        <p className="text-sm text-gray-500 flex items-center">
                          <Calendar size={14} className="mr-1" />
                          {new Date(payment.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-900">
                        ${payment.amount} {payment.currency}
                      </p>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(payment.status)}`}>
                        {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">No payment history available</p>
            )}
          </div>
        </div>

        {/* Current Plan */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Current Plan</h2>
          
          {currentPlan ? (
            <div className="space-y-6">
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-medium text-gray-900">{currentPlan.name}</h3>
                  <span className="text-2xl font-bold text-gray-900">${currentPlan.price}</span>
                </div>
                <p className="text-sm text-gray-500 mb-4">per {currentPlan.interval}</p>
                
                <div className="space-y-2">
                  {currentPlan.features.map((feature: string, index: number) => (
                    <div key={index} className="flex items-center text-sm text-gray-600">
                      <Check size={16} className="text-green-500 mr-2" />
                      {feature}
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                {user?.subscription_tier === 'free' && (
                  <button
                    onClick={() => handleUpgrade('calyra-core')}
                    className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    Upgrade to Core
                  </button>
                )}

                {user?.subscription_tier === 'core' && (
                  <button
                    onClick={() => handleUpgrade('calyra-growth')}
                    className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    Upgrade to Growth
                  </button>
                )}

                {user?.subscription_tier === 'growth' && (
                  <button
                    onClick={() => handleUpgrade('calyra-enterprise')}
                    className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    Upgrade to Enterprise
                  </button>
                )}

                {user?.subscription_tier !== 'free' && (
                  <button
                    onClick={handleCancelSubscription}
                    className="w-full bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500"
                  >
                    Cancel Subscription
                  </button>
                )}
              </div>
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8">No active plan</p>
          )}
        </div>
      </div>

      {/* Available Plans */}
      <div className="mt-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Available Plans</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {PAYMENT_PLANS.map((plan) => (
              <div key={plan.id} className="border border-gray-200 rounded-lg p-6">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-semibold text-gray-900">{plan.name}</h3>
                  <div className="mt-2">
                    <span className="text-3xl font-bold text-gray-900">${plan.price}</span>
                    <span className="text-gray-500">/{plan.interval}</span>
                  </div>
                </div>

                <div className="space-y-3 mb-6">
                  {plan.features.map((feature, index) => (
                    <div key={index} className="flex items-center text-sm text-gray-600">
                      <Check size={16} className="text-green-500 mr-2" />
                      {feature}
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => handleUpgrade(plan.id)}
                  disabled={user?.subscription_tier === plan.id.replace('calyra-', '')}
                  className={`w-full py-2 px-4 rounded-lg font-medium focus:outline-none focus:ring-2 ${
                    user?.subscription_tier === plan.id.replace('calyra-', '')
                      ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                      : 'bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500'
                  }`}
                >
                  {user?.subscription_tier === plan.id.replace('calyra-', '') 
                    ? 'Current Plan' 
                    : 'Choose Plan'
                  }
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Billing Information */}
      <div className="mt-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Billing Information</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-medium text-gray-900 mb-2">Contact Information</h3>
              <p className="text-sm text-gray-600">{user?.full_name || 'Not provided'}</p>
              <p className="text-sm text-gray-600">{user?.email}</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-900 mb-2">Next Billing Date</h3>
              <p className="text-sm text-gray-600">
                {user?.subscription_tier === 'free' 
                  ? 'No billing date' 
                  : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()
                }
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

