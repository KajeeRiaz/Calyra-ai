import { Link } from 'react-router-dom'
import { Check } from 'lucide-react'

const Pricing = () => {
  const plans = [
    {
      name: "Calyra Core",
      price: "$199",
      period: "per year",
      description: "Perfect for individual entrepreneurs",
      features: [
        "Daily validated startup ideas",
        "Basic validation tools",
        "Community access",
        "Email support",
        "Basic idea analysis"
      ],
      popular: false
    },
    {
      name: "Calyra Growth",
      price: "$1,499",
      period: "per year",
      description: "For serious entrepreneurs and small teams",
      features: [
        "Everything in Core",
        "VC-Grade Builder (6 templates)",
        "Expert Framework Analysis",
        "AI Chat per Idea",
        "Advanced validation frameworks",
        "Priority support",
        "Custom reports"
      ],
      popular: true
    },
    {
      name: "Calyra Enterprise",
      price: "Custom",
      period: "contact us",
      description: "For institutional clients and large teams",
      features: [
        "Everything in Growth",
        "White-label solutions",
        "API access",
        "Dedicated account manager",
        "Custom integrations",
        "Team collaboration tools",
        "Advanced market intelligence"
      ],
      popular: false
    }
  ]

  const oneTimeReports = [
    {
      name: "Quick Validation Report",
      price: "$49",
      description: "Basic idea validation with market analysis",
      features: [
        "Market size assessment",
        "Competitive landscape",
        "Basic feasibility analysis",
        "Risk assessment",
        "Next steps recommendations"
      ]
    },
    {
      name: "Deep Analysis Report",
      price: "$149",
      description: "Comprehensive analysis with expert frameworks",
      features: [
        "Everything in Quick Report",
        "Warren Buffett framework analysis",
        "VC investment criteria evaluation",
        "Porter's Five Forces analysis",
        "Blue Ocean Strategy assessment",
        "Financial projections",
        "Go-to-market strategy"
      ]
    },
    {
      name: "Market Intelligence Report",
      price: "$299",
      description: "Enterprise-grade market intelligence",
      features: [
        "Everything in Deep Analysis",
        "Advanced competitive intelligence",
        "Market trend analysis",
        "Customer segmentation",
        "Pricing strategy analysis",
        "Technology stack recommendations",
        "Investment readiness assessment"
      ]
    }
  ]

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Simple, Transparent Pricing</h1>
        <p className="text-xl text-gray-600">Choose the plan that fits your entrepreneurial journey</p>
      </div>

      {/* Subscription Plans */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">Subscription Plans</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div 
              key={index} 
              className={`bg-white rounded-2xl shadow-xl p-8 ${
                plan.popular ? 'ring-2 ring-blue-500 relative' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-blue-500 text-white px-4 py-2 rounded-full text-sm font-semibold">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                <div className="mb-2">
                  <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                  <span className="text-gray-600 ml-2">{plan.period}</span>
                </div>
                <p className="text-gray-600">{plan.description}</p>
              </div>
              
              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <button 
                className={`w-full py-3 px-6 rounded-lg font-semibold transition-colors ${
                  plan.popular 
                    ? 'bg-blue-600 text-white hover:bg-blue-700' 
                    : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
                }`}
              >
                {plan.name === "Calyra Enterprise" ? "Contact Sales" : "Get Started"}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* One-Time Reports */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">One-Time Reports</h2>
        <p className="text-center text-gray-600 mb-8">Get instant expert analysis for individual ideas</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {oneTimeReports.map((report, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
              <div className="text-center mb-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{report.name}</h3>
                <div className="mb-2">
                  <span className="text-3xl font-bold text-gray-900">{report.price}</span>
                  <span className="text-gray-600 ml-1">one-time</span>
                </div>
                <p className="text-gray-600 text-sm">{report.description}</p>
              </div>
              
              <ul className="space-y-3 mb-6">
                {report.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-start">
                    <Check className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <button className="w-full py-2 px-4 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition-colors">
                Get Report
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Additional Info */}
      <div className="text-center">
        <p className="text-gray-600 mb-4">All plans include a 14-day free trial</p>
        <p className="text-sm text-gray-500 mb-6">No credit card required to start</p>
        
        <div className="bg-gray-50 rounded-lg p-6 max-w-2xl mx-auto">
          <h3 className="font-semibold text-gray-900 mb-3">Why Choose Calyra.ai?</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
            <div className="flex items-center">
              <Check className="w-4 h-4 text-green-500 mr-2" />
              <span>Institutional-grade analysis</span>
            </div>
            <div className="flex items-center">
              <Check className="w-4 h-4 text-green-500 mr-2" />
              <span>AI-powered insights</span>
            </div>
            <div className="flex items-center">
              <Check className="w-4 h-4 text-green-500 mr-2" />
              <span>Expert frameworks</span>
            </div>
            <div className="flex items-center">
              <Check className="w-4 h-4 text-green-500 mr-2" />
              <span>VC-quality materials</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Pricing
