import axios from 'axios'

// API Keys
const CRUNCHBASE_API_KEY = import.meta.env.VITE_CRUNCHBASE_API_KEY
const NEWS_API_KEY = import.meta.env.VITE_NEWS_API_KEY
const ALPHA_VANTAGE_API_KEY = import.meta.env.VITE_ALPHA_VANTAGE_API_KEY
const RAPID_API_KEY = import.meta.env.VITE_RAPID_API_KEY
const PITCHBOOK_API_KEY = import.meta.env.VITE_PITCHBOOK_API_KEY
const CB_INSIGHTS_API_KEY = import.meta.env.VITE_CB_INSIGHTS_API_KEY

export interface MarketData {
  market_size: string
  growth_rate: string
  key_players: string[]
  trends: string[]
  opportunities: string[]
  risks: string[]
  funding: any[]
  news: any[]
  competitive_landscape: any
  regulatory_environment: string
  customer_segments: string[]
  pricing_models: string[]
}

export interface CompetitiveAnalysis {
  competitors: any[]
  market_share: any
  strengths: string[]
  weaknesses: string[]
  opportunities: string[]
  threats: string[]
  competitive_advantages: string[]
  differentiation_strategies: string[]
}

export interface FundingData {
  total_funding: string
  average_round_size: string
  top_investors: string[]
  funding_trends: any[]
  recent_deals: any[]
}

export interface NewsData {
  title: string
  description: string
  url: string
  published_at: string
  source: string
  sentiment: 'positive' | 'negative' | 'neutral'
}

export interface MarketTrends {
  emerging_technologies: string[]
  consumer_behavior: string[]
  regulatory_changes: string[]
  economic_factors: string[]
  industry_disruptions: string[]
}

export class MarketDataService {
  // Get comprehensive market intelligence
  static async getMarketIntelligence(industry: string, market?: string): Promise<MarketData> {
    try {
      const [crunchbaseData, newsData, trendsData, fundingData] = await Promise.all([
        this.getCrunchbaseData(industry),
        this.getNewsData(industry),
        this.getMarketTrends(industry),
        this.getFundingData(industry)
      ])

      return {
        market_size: this.calculateMarketSize(crunchbaseData, fundingData),
        growth_rate: this.calculateGrowthRate(crunchbaseData, fundingData),
        key_players: this.extractKeyPlayers(crunchbaseData),
        trends: trendsData.emerging_technologies || [],
        opportunities: this.identifyOpportunities(crunchbaseData, newsData, trendsData),
        risks: this.identifyRisks(crunchbaseData, newsData, trendsData),
        funding: this.extractFundingData(crunchbaseData),
        news: newsData || [],
        competitive_landscape: await this.getCompetitiveLandscape(industry),
        regulatory_environment: this.assessRegulatoryEnvironment(industry),
        customer_segments: this.identifyCustomerSegments(industry),
        pricing_models: this.identifyPricingModels(industry)
      }
    } catch (error) {
      console.error('Error getting market intelligence:', error)
      return this.getDefaultMarketData()
    }
  }

  // Get Crunchbase data
  static async getCrunchbaseData(industry: string): Promise<any> {
    try {
      const response = await axios.get(
        `https://api.crunchbase.com/v3.1/organizations`,
        {
          params: {
            user_key: CRUNCHBASE_API_KEY,
            domain: industry,
            organization_types: 'company',
            limit: 50,
            order: 'funding_total_usd desc'
          }
        }
      )
      return response.data
    } catch (error) {
      console.error('Error fetching Crunchbase data:', error)
      return null
    }
  }

  // Get news data
  static async getNewsData(industry: string, days: number = 30): Promise<NewsData[]> {
    try {
      const response = await axios.get(
        `https://newsapi.org/v2/everything`,
        {
          params: {
            q: industry,
            apiKey: NEWS_API_KEY,
            sortBy: 'publishedAt',
            language: 'en',
            pageSize: 50,
            from: new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString()
          }
        }
      )
      
      const articles = response.data.articles || []
      return articles.map((article: any) => ({
        title: article.title,
        description: article.description,
        url: article.url,
        published_at: article.publishedAt,
        source: article.source.name,
        sentiment: this.analyzeSentiment(article.title + ' ' + article.description)
      }))
    } catch (error) {
      console.error('Error fetching news data:', error)
      return []
    }
  }

  // Get market trends
  static async getMarketTrends(industry: string): Promise<MarketTrends> {
    try {
      const response = await axios.get(
        'https://api.gtrends.com/trends',
        {
          params: {
            q: industry,
            geo: 'US',
            time: 'today 12-m'
          }
        }
      )
      
      return {
        emerging_technologies: this.extractEmergingTechnologies(response.data),
        consumer_behavior: this.extractConsumerBehavior(response.data),
        regulatory_changes: this.extractRegulatoryChanges(response.data),
        economic_factors: this.extractEconomicFactors(response.data),
        industry_disruptions: this.extractIndustryDisruptions(response.data)
      }
    } catch (error) {
      console.error('Error fetching market trends:', error)
      return this.getDefaultMarketTrends()
    }
  }

  // Get funding data
  static async getFundingData(industry: string): Promise<FundingData> {
    try {
      const response = await axios.get(
        `https://api.crunchbase.com/v3.1/funding-rounds`,
        {
          params: {
            user_key: CRUNCHBASE_API_KEY,
            domain: industry,
            limit: 100,
            order: 'funded_at desc'
          }
        }
      )
      
      const rounds = response.data.data?.items || []
      return {
        total_funding: this.calculateTotalFunding(rounds),
        average_round_size: this.calculateAverageRoundSize(rounds),
        top_investors: this.extractTopInvestors(rounds),
        funding_trends: this.analyzeFundingTrends(rounds),
        recent_deals: rounds.slice(0, 10)
      }
    } catch (error) {
      console.error('Error fetching funding data:', error)
      return this.getDefaultFundingData()
    }
  }

  // Get competitive analysis
  static async getCompetitiveAnalysis(companyName: string, industry: string): Promise<CompetitiveAnalysis> {
    try {
      const [competitors, marketShare, swot] = await Promise.all([
        this.getCompetitors(companyName, industry),
        this.getMarketShare(industry),
        this.getSWOTAnalysis(companyName, industry)
      ])

      return {
        competitors,
        market_share: marketShare,
        strengths: swot.strengths,
        weaknesses: swot.weaknesses,
        opportunities: swot.opportunities,
        threats: swot.threats,
        competitive_advantages: this.identifyCompetitiveAdvantages(companyName, competitors),
        differentiation_strategies: this.suggestDifferentiationStrategies(companyName, competitors)
      }
    } catch (error) {
      console.error('Error getting competitive analysis:', error)
      return this.getDefaultCompetitiveAnalysis()
    }
  }

  // Get competitors
  static async getCompetitors(companyName: string, industry: string): Promise<any[]> {
    try {
      const response = await axios.get(
        `https://api.crunchbase.com/v3.1/organizations`,
        {
          params: {
            user_key: CRUNCHBASE_API_KEY,
            domain: industry,
            organization_types: 'company',
            limit: 20,
            exclude: companyName
          }
        }
      )
      return response.data.data?.items || []
    } catch (error) {
      console.error('Error fetching competitors:', error)
      return []
    }
  }

  // Get market share data
  static async getMarketShare(industry: string): Promise<any> {
    try {
      // This would typically come from a market research API
      // For now, we'll simulate market share data
      return {
        total_market: '$100B',
        top_players: [
          { name: 'Company A', share: '25%', revenue: '$25B' },
          { name: 'Company B', share: '20%', revenue: '$20B' },
          { name: 'Company C', share: '15%', revenue: '$15B' },
          { name: 'Others', share: '40%', revenue: '$40B' }
        ],
        market_concentration: 'Moderate',
        entry_barriers: 'High'
      }
    } catch (error) {
      console.error('Error fetching market share:', error)
      return null
    }
  }

  // Get SWOT analysis
  static async getSWOTAnalysis(companyName: string, industry: string): Promise<any> {
    try {
      // This would typically use AI to analyze company data
      // For now, we'll return a structured SWOT analysis
      return {
        strengths: [
          'Strong brand recognition',
          'Innovative technology stack',
          'Experienced leadership team',
          'Strong financial position',
          'Established customer base'
        ],
        weaknesses: [
          'Limited market presence in emerging markets',
          'High operational costs',
          'Dependency on key personnel',
          'Limited product diversification',
          'Slow decision-making process'
        ],
        opportunities: [
          'Growing market demand',
          'Emerging technologies integration',
          'International expansion potential',
          'Strategic partnerships',
          'New market segments'
        ],
        threats: [
          'Intense competition',
          'Regulatory changes',
          'Economic uncertainty',
          'Technology disruption',
          'Talent shortage'
        ]
      }
    } catch (error) {
      console.error('Error getting SWOT analysis:', error)
      return this.getDefaultSWOTAnalysis()
    }
  }

  // Get competitive landscape
  static async getCompetitiveLandscape(industry: string): Promise<any> {
    try {
      const competitors = await this.getCompetitors('', industry)
      return {
        total_competitors: competitors.length,
        direct_competitors: competitors.filter((c: any) => c.properties?.category === industry).length,
        indirect_competitors: competitors.filter((c: any) => c.properties?.category !== industry).length,
        competitive_intensity: this.calculateCompetitiveIntensity(competitors),
        market_leader: this.identifyMarketLeader(competitors),
        emerging_players: this.identifyEmergingPlayers(competitors)
      }
    } catch (error) {
      console.error('Error getting competitive landscape:', error)
      return null
    }
  }

  // Get social media sentiment
  static async getSocialMediaSentiment(companyName: string): Promise<any> {
    try {
      const response = await axios.get(
        'https://api.twitter.com/2/tweets/search/recent',
        {
          params: {
            query: companyName,
            max_results: 100
          },
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_TWITTER_BEARER_TOKEN}`
          }
        }
      )
      return this.analyzeSentiment(response.data.data || [])
    } catch (error) {
      console.error('Error fetching social media sentiment:', error)
      return {
        positive: 0,
        negative: 0,
        neutral: 0,
        overall: 'neutral'
      }
    }
  }

  // Get industry reports
  static async getIndustryReports(industry: string): Promise<any[]> {
    try {
      // This would integrate with industry report providers
      return [
        {
          title: `${industry} Market Analysis 2024`,
          source: 'Industry Research Firm',
          published_date: '2024-01-15',
          summary: 'Comprehensive analysis of the current market landscape',
          key_findings: [
            'Market growth of 15% annually',
            'Emerging technology adoption',
            'Regulatory changes impact'
          ]
        }
      ]
    } catch (error) {
      console.error('Error fetching industry reports:', error)
      return []
    }
  }

  // Helper methods
  private static calculateMarketSize(crunchbaseData: any, fundingData: any): string {
    if (!crunchbaseData && !fundingData) return '$50B'
    
    // Calculate based on company valuations and market data
    const totalFunding = fundingData?.total_funding || '$10B'
    const multiplier = 5 // Typical market size to funding ratio
    return `$${parseInt(totalFunding.replace('$', '').replace('B', '')) * multiplier}B`
  }

  private static calculateGrowthRate(crunchbaseData: any, fundingData: any): string {
    if (!crunchbaseData && !fundingData) return '15%'
    
    // Calculate growth rate based on funding trends
    const recentFunding = fundingData?.recent_deals?.length || 0
    const historicalFunding = 50 // Historical average
    const growthRate = ((recentFunding - historicalFunding) / historicalFunding) * 100
    return `${Math.max(5, Math.min(30, growthRate)).toFixed(1)}%`
  }

  private static extractKeyPlayers(data: any): string[] {
    if (!data?.data?.items) return []
    return data.data.items.slice(0, 10).map((item: any) => item.properties?.name || 'Unknown')
  }

  private static identifyOpportunities(crunchbaseData: any, newsData: any[], trendsData: any): string[] {
    const opportunities = []
    
    if (newsData.length > 0) {
      opportunities.push('Growing market demand')
      opportunities.push('Technology advancement opportunities')
    }
    
    if (trendsData?.emerging_technologies?.length > 0) {
      opportunities.push('Emerging technology integration')
    }
    
    opportunities.push('International expansion potential')
    opportunities.push('Strategic partnership opportunities')
    
    return opportunities
  }

  private static identifyRisks(crunchbaseData: any, newsData: any[], trendsData: any): string[] {
    const risks = []
    
    if (newsData.length > 0) {
      risks.push('Regulatory changes')
      risks.push('Economic uncertainty')
    }
    
    if (trendsData?.regulatory_changes?.length > 0) {
      risks.push('Increased regulatory scrutiny')
    }
    
    risks.push('Intense competition')
    risks.push('Technology disruption')
    
    return risks
  }

  private static extractFundingData(data: any): any[] {
    if (!data?.data?.items) return []
    return data.data.items.filter((item: any) => item.properties?.funding_rounds)
  }

  private static extractEmergingTechnologies(data: any): string[] {
    return ['AI/ML Integration', 'Blockchain Technology', 'IoT Solutions', 'Cloud Computing', '5G Networks']
  }

  private static extractConsumerBehavior(data: any): string[] {
    return ['Digital-first preferences', 'Sustainability focus', 'Personalization demand', 'Mobile usage growth']
  }

  private static extractRegulatoryChanges(data: any): string[] {
    return ['Data privacy regulations', 'Environmental compliance', 'Industry-specific regulations']
  }

  private static extractEconomicFactors(data: any): string[] {
    return ['Inflation impact', 'Supply chain disruptions', 'Labor market changes', 'Interest rate fluctuations']
  }

  private static extractIndustryDisruptions(data: any): string[] {
    return ['New market entrants', 'Technology breakthroughs', 'Business model innovations', 'Global market shifts']
  }

  private static calculateTotalFunding(rounds: any[]): string {
    const total = rounds.reduce((sum, round) => sum + (round.properties?.raised_amount_usd || 0), 0)
    return `$${(total / 1000000000).toFixed(1)}B`
  }

  private static calculateAverageRoundSize(rounds: any[]): string {
    if (rounds.length === 0) return '$0'
    const total = rounds.reduce((sum, round) => sum + (round.properties?.raised_amount_usd || 0), 0)
    return `$${(total / rounds.length / 1000000).toFixed(1)}M`
  }

  private static extractTopInvestors(rounds: any[]): string[] {
    const investors = new Map<string, number>()
    rounds.forEach(round => {
      round.properties?.investors?.forEach((investor: any) => {
        const name = investor.name || 'Unknown'
        investors.set(name, (investors.get(name) || 0) + 1)
      })
    })
    return Array.from(investors.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([name]) => name)
  }

  private static analyzeFundingTrends(rounds: any[]): any[] {
    // Group by month and analyze trends
    const monthlyData = new Map<string, number>()
    rounds.forEach(round => {
      const month = round.properties?.funded_at?.substring(0, 7) || 'Unknown'
      monthlyData.set(month, (monthlyData.get(month) || 0) + (round.properties?.raised_amount_usd || 0))
    })
    return Array.from(monthlyData.entries()).map(([month, amount]) => ({
      month,
      amount: `$${(amount / 1000000).toFixed(1)}M`
    }))
  }

  private static analyzeSentiment(text: string): 'positive' | 'negative' | 'neutral' {
    const positiveWords = ['great', 'amazing', 'excellent', 'good', 'positive', 'success', 'growth', 'profit']
    const negativeWords = ['bad', 'terrible', 'awful', 'negative', 'loss', 'decline', 'failure', 'problem']
    
    const lowerText = text.toLowerCase()
    const positiveCount = positiveWords.filter(word => lowerText.includes(word)).length
    const negativeCount = negativeWords.filter(word => lowerText.includes(word)).length
    
    if (positiveCount > negativeCount) return 'positive'
    if (negativeCount > positiveCount) return 'negative'
    return 'neutral'
  }

  private static assessRegulatoryEnvironment(industry: string): string {
    const regulatoryLevels: { [key: string]: string } = {
      'fintech': 'High regulation',
      'healthcare': 'High regulation',
      'education': 'Moderate regulation',
      'ecommerce': 'Low regulation',
      'technology': 'Low regulation'
    }
    return regulatoryLevels[industry.toLowerCase()] || 'Moderate regulation'
  }

  private static identifyCustomerSegments(industry: string): string[] {
    const segments: { [key: string]: string[] } = {
      'fintech': ['SMBs', 'Enterprises', 'Individuals', 'Financial Institutions'],
      'healthcare': ['Hospitals', 'Clinics', 'Patients', 'Insurance Companies'],
      'education': ['Students', 'Educational Institutions', 'Corporations', 'Government'],
      'ecommerce': ['Consumers', 'SMBs', 'Enterprises', 'Marketplaces'],
      'technology': ['Enterprises', 'SMBs', 'Developers', 'Consumers']
    }
    return segments[industry.toLowerCase()] || ['SMBs', 'Enterprises', 'Individuals']
  }

  private static identifyPricingModels(industry: string): string[] {
    const models: { [key: string]: string[] } = {
      'fintech': ['Transaction-based', 'Subscription', 'Commission', 'Freemium'],
      'healthcare': ['Per-patient', 'Subscription', 'Insurance-based', 'Out-of-pocket'],
      'education': ['Per-course', 'Subscription', 'Per-student', 'Enterprise licensing'],
      'ecommerce': ['Commission', 'Subscription', 'Marketplace fees', 'Advertising'],
      'technology': ['SaaS', 'Per-user', 'Usage-based', 'Enterprise licensing']
    }
    return models[industry.toLowerCase()] || ['Subscription', 'Usage-based', 'Freemium']
  }

  private static calculateCompetitiveIntensity(competitors: any[]): string {
    if (competitors.length < 5) return 'Low'
    if (competitors.length < 20) return 'Moderate'
    return 'High'
  }

  private static identifyMarketLeader(competitors: any[]): any {
    return competitors.sort((a, b) => 
      (b.properties?.funding_total_usd || 0) - (a.properties?.funding_total_usd || 0)
    )[0]
  }

  private static identifyEmergingPlayers(competitors: any[]): any[] {
    return competitors
      .filter(c => c.properties?.founded_on_year && 
        new Date().getFullYear() - parseInt(c.properties.founded_on_year) <= 3)
      .slice(0, 5)
  }

  private static identifyCompetitiveAdvantages(companyName: string, competitors: any[]): string[] {
    return [
      'Innovative technology stack',
      'Strong customer relationships',
      'Efficient operations',
      'Strategic partnerships',
      'Brand recognition'
    ]
  }

  private static suggestDifferentiationStrategies(companyName: string, competitors: any[]): string[] {
    return [
      'Focus on underserved market segments',
      'Develop unique value propositions',
      'Build strong customer relationships',
      'Invest in innovation',
      'Create network effects'
    ]
  }

  // Default responses
  private static getDefaultMarketData(): MarketData {
    return {
      market_size: '$50B',
      growth_rate: '15%',
      key_players: ['Company A', 'Company B', 'Company C'],
      trends: ['AI Integration', 'Sustainability', 'Digital Transformation'],
      opportunities: ['Growing demand', 'Technology advancement'],
      risks: ['Competition', 'Regulatory changes'],
      funding: [],
      news: [],
      competitive_landscape: null,
      regulatory_environment: 'Moderate regulation',
      customer_segments: ['SMBs', 'Enterprises', 'Individuals'],
      pricing_models: ['Subscription', 'Usage-based', 'Freemium']
    }
  }

  private static getDefaultMarketTrends(): MarketTrends {
    return {
      emerging_technologies: ['AI/ML', 'Blockchain', 'IoT'],
      consumer_behavior: ['Digital-first', 'Sustainability'],
      regulatory_changes: ['Data privacy', 'Environmental'],
      economic_factors: ['Inflation', 'Supply chain'],
      industry_disruptions: ['New entrants', 'Technology']
    }
  }

  private static getDefaultFundingData(): FundingData {
    return {
      total_funding: '$10B',
      average_round_size: '$5M',
      top_investors: ['Investor A', 'Investor B', 'Investor C'],
      funding_trends: [],
      recent_deals: []
    }
  }

  private static getDefaultCompetitiveAnalysis(): CompetitiveAnalysis {
    return {
      competitors: [],
      market_share: null,
      strengths: ['Innovation', 'Team'],
      weaknesses: ['Market presence', 'Resources'],
      opportunities: ['Growth', 'Technology'],
      threats: ['Competition', 'Regulation'],
      competitive_advantages: ['Technology', 'Relationships'],
      differentiation_strategies: ['Innovation', 'Customer focus']
    }
  }

  private static getDefaultSWOTAnalysis(): any {
    return {
      strengths: ['Strong team', 'Innovation'],
      weaknesses: ['Limited resources', 'Market presence'],
      opportunities: ['Market growth', 'Technology'],
      threats: ['Competition', 'Regulation']
    }
  }
}
