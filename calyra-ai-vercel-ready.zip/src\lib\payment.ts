import axios from 'axios'

// Paystack Configuration
const PAYSTACK_SECRET_KEY = import.meta.env.VITE_PAYSTACK_SECRET_KEY
const PAYSTACK_PUBLIC_KEY = import.meta.env.VITE_PAYSTACK_PUBLIC_KEY

export interface PaymentPlan {
  id: string
  name: string
  price: number
  currency: string
  interval: 'monthly' | 'yearly'
  features: string[]
  limits: {
    ideas: number
    analyses: number
    validations: number
    chats: number
    exports: number
  }
  popular?: boolean
}

export interface PaymentResult {
  success: boolean
  data?: any
  error?: string
  redirect_url?: string
}

export interface SubscriptionData {
  id: string
  user_id: string
  plan_id: string
  status: string
  current_period_start: string
  current_period_end: string
  cancel_at_period_end: boolean
}

export const PAYMENT_PLANS: PaymentPlan[] = [
  {
    id: 'calyra-free',
    name: 'Calyra Free',
    price: 0,
    currency: 'USD',
    interval: 'monthly',
    features: [
      'Daily validated startup ideas',
      'Basic idea validation tools',
      'Community access',
      'Email support',
      'Limited AI chat (5 messages/day)',
      'Basic framework analysis (1/month)'
    ],
    limits: {
      ideas: 5,
      analyses: 1,
      validations: 2,
      chats: 5,
      exports: 0
    }
  },
  {
    id: 'calyra-core',
    name: 'Calyra Core',
    price: 19,
    currency: 'USD',
    interval: 'monthly',
    features: [
      'Everything in Free',
      'Advanced validation tools',
      'Priority support',
      'Unlimited AI chat',
      'Framework analysis (5/month)',
      'Market intelligence reports',
      'Export to PDF',
      'Idea templates library'
    ],
    limits: {
      ideas: 25,
      analyses: 5,
      validations: 10,
      chats: -1, // unlimited
      exports: 5
    }
  },
  {
    id: 'calyra-growth',
    name: 'Calyra Growth',
    price: 49,
    currency: 'USD',
    interval: 'monthly',
    popular: true,
    features: [
      'Everything in Core',
      'VC-Grade Builder (6 templates)',
      'Expert Framework Analysis (unlimited)',
      'Advanced validation frameworks',
      'Competitive analysis tools',
      'Financial projections',
      'Business plan generation',
      'Priority support',
      'API access',
      'White-label options'
    ],
    limits: {
      ideas: 100,
      analyses: -1, // unlimited
      validations: -1, // unlimited
      chats: -1, // unlimited
      exports: 25
    }
  },
  {
    id: 'calyra-enterprise',
    name: 'Calyra Enterprise',
    price: 199,
    currency: 'USD',
    interval: 'monthly',
    features: [
      'Everything in Growth',
      'Unlimited everything',
      'Custom integrations',
      'Dedicated account manager',
      'Custom AI model training',
      'Advanced analytics dashboard',
      'Team collaboration tools',
      'Custom branding',
      'SLA guarantee',
      'Onboarding support'
    ],
    limits: {
      ideas: -1, // unlimited
      analyses: -1, // unlimited
      validations: -1, // unlimited
      chats: -1, // unlimited
      exports: -1 // unlimited
    }
  }
]

export const YEARLY_PLANS: PaymentPlan[] = PAYMENT_PLANS.map(plan => ({
  ...plan,
  id: `${plan.id}-yearly`,
  price: Math.round(plan.price * 10), // 2 months free
  interval: 'yearly' as const
}))

export class PaymentService {
  // Initialize payment
  static async initializePayment(planId: string, email: string, currency: string = 'USD'): Promise<PaymentResult> {
    try {
      const plan = [...PAYMENT_PLANS, ...YEARLY_PLANS].find(p => p.id === planId)
      if (!plan) {
        return { success: false, error: 'Invalid plan selected' }
      }

      const response = await axios.post(
        'https://api.paystack.co/transaction/initialize',
        {
          email,
          amount: plan.price * 100, // Convert to kobo/cents
          currency: currency.toLowerCase(),
          callback_url: `${window.location.origin}/payment/success`,
          metadata: {
            plan_id: planId,
            plan_name: plan.name,
            plan_price: plan.price,
            plan_currency: plan.currency,
            plan_interval: plan.interval
          }
        },
        {
          headers: {
            'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
            'Content-Type': 'application/json'
          }
        }
      )

      if (response.data.status) {
        return {
          success: true,
          data: response.data.data,
          redirect_url: response.data.data.authorization_url
        }
      } else {
        return { success: false, error: 'Failed to initialize payment' }
      }
    } catch (error: any) {
      console.error('Error initializing payment:', error)
      return {
        success: false,
        error: error.response?.data?.message || 'Payment initialization failed'
      }
    }
  }

  // Verify payment
  static async verifyPayment(reference: string): Promise<PaymentResult> {
    try {
      const response = await axios.get(
        `https://api.paystack.co/transaction/verify/${reference}`,
        {
          headers: {
            'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`
          }
        }
      )

      if (response.data.status && response.data.data.status === 'success') {
        return {
          success: true,
          data: response.data.data
        }
      } else {
        return { success: false, error: 'Payment verification failed' }
      }
    } catch (error: any) {
      console.error('Error verifying payment:', error)
      return {
        success: false,
        error: error.response?.data?.message || 'Payment verification failed'
      }
    }
  }

  // Create customer
  static async createCustomer(email: string, firstName: string, lastName: string): Promise<PaymentResult> {
    try {
      const response = await axios.post(
        'https://api.paystack.co/customer',
        {
          email,
          first_name: firstName,
          last_name: lastName
        },
        {
          headers: {
            'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
            'Content-Type': 'application/json'
          }
        }
      )

      if (response.data.status) {
        return {
          success: true,
          data: response.data.data
        }
      } else {
        return { success: false, error: 'Failed to create customer' }
      }
    } catch (error: any) {
      console.error('Error creating customer:', error)
      return {
        success: false,
        error: error.response?.data?.message || 'Customer creation failed'
      }
    }
  }

  // Create subscription
  static async createSubscription(customerCode: string, planCode: string): Promise<PaymentResult> {
    try {
      const response = await axios.post(
        'https://api.paystack.co/subscription',
        {
          customer: customerCode,
          plan: planCode
        },
        {
          headers: {
            'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
            'Content-Type': 'application/json'
          }
        }
      )

      if (response.data.status) {
        return {
          success: true,
          data: response.data.data
        }
      } else {
        return { success: false, error: 'Failed to create subscription' }
      }
    } catch (error: any) {
      console.error('Error creating subscription:', error)
      return {
        success: false,
        error: error.response?.data?.message || 'Subscription creation failed'
      }
    }
  }

  // Get customer subscriptions
  static async getCustomerSubscriptions(customerCode: string): Promise<PaymentResult> {
    try {
      const response = await axios.get(
        `https://api.paystack.co/subscription?customer=${customerCode}`,
        {
          headers: {
            'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`
          }
        }
      )

      if (response.data.status) {
        return {
          success: true,
          data: response.data.data
        }
      } else {
        return { success: false, error: 'Failed to fetch subscriptions' }
      }
    } catch (error: any) {
      console.error('Error fetching subscriptions:', error)
      return {
        success: false,
        error: error.response?.data?.message || 'Failed to fetch subscriptions'
      }
    }
  }

  // Cancel subscription
  static async cancelSubscription(subscriptionCode: string): Promise<PaymentResult> {
    try {
      const response = await axios.post(
        `https://api.paystack.co/subscription/disable`,
        {
          code: subscriptionCode,
          token: 'disable_token' // This would be generated by Paystack
        },
        {
          headers: {
            'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
            'Content-Type': 'application/json'
          }
        }
      )

      if (response.data.status) {
        return {
          success: true,
          data: response.data.data
        }
      } else {
        return { success: false, error: 'Failed to cancel subscription' }
      }
    } catch (error: any) {
      console.error('Error cancelling subscription:', error)
      return {
        success: false,
        error: error.response?.data?.message || 'Failed to cancel subscription'
      }
    }
  }

  // Get payment plans from Paystack
  static async getPaystackPlans(): Promise<PaymentResult> {
    try {
      const response = await axios.get(
        'https://api.paystack.co/plan',
        {
          headers: {
            'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`
          }
        }
      )

      if (response.data.status) {
        return {
          success: true,
          data: response.data.data
        }
      } else {
        return { success: false, error: 'Failed to fetch plans' }
      }
    } catch (error: any) {
      console.error('Error fetching Paystack plans:', error)
      return {
        success: false,
        error: error.response?.data?.message || 'Failed to fetch plans'
      }
    }
  }

  // Handle webhook
  static async handleWebhook(event: any): Promise<void> {
    try {
      switch (event.event) {
        case 'charge.success':
          await this.handleSuccessfulPayment(event.data)
          break
        case 'subscription.create':
          await this.handleSubscriptionCreated(event.data)
          break
        case 'subscription.disable':
          await this.handleSubscriptionDisabled(event.data)
          break
        case 'subscription.not_renew':
          await this.handleSubscriptionNotRenewed(event.data)
          break
        case 'transfer.success':
          await this.handleTransferSuccess(event.data)
          break
        default:
          console.log('Unhandled webhook event:', event.event)
      }
    } catch (error) {
      console.error('Error handling webhook:', error)
      throw error
    }
  }

  // Get plan by ID
  static getPlanById(planId: string): PaymentPlan | undefined {
    return [...PAYMENT_PLANS, ...YEARLY_PLANS].find(plan => plan.id === planId)
  }

  // Get plan limits
  static getPlanLimits(planId: string): PaymentPlan['limits'] | null {
    const plan = this.getPlanById(planId)
    return plan ? plan.limits : null
  }

  // Check if user can perform action
  static canPerformAction(
    userPlan: string,
    userUsage: { [key: string]: number },
    action: keyof PaymentPlan['limits']
  ): boolean {
    const limits = this.getPlanLimits(userPlan)
    if (!limits) return false

    const limit = limits[action]
    const usage = userUsage[action] || 0

    return limit === -1 || usage < limit
  }

  // Calculate usage percentage
  static getUsagePercentage(
    userPlan: string,
    userUsage: { [key: string]: number },
    action: keyof PaymentPlan['limits']
  ): number {
    const limits = this.getPlanLimits(userPlan)
    if (!limits || limits[action] === -1) return 0

    const usage = userUsage[action] || 0
    return Math.min((usage / limits[action]) * 100, 100)
  }

  // Format currency
  static formatCurrency(amount: number, currency: string = 'USD'): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency.toUpperCase()
    }).format(amount)
  }

  // Get plan features
  static getPlanFeatures(planId: string): string[] {
    const plan = this.getPlanById(planId)
    return plan ? plan.features : []
  }

  // Compare plans
  static comparePlans(plan1Id: string, plan2Id: string): {
    plan1: PaymentPlan | undefined
    plan2: PaymentPlan | undefined
    differences: {
      feature: string
      plan1: boolean
      plan2: boolean
    }[]
  } {
    const plan1 = this.getPlanById(plan1Id)
    const plan2 = this.getPlanById(plan2Id)

    if (!plan1 || !plan2) {
      return { plan1, plan2, differences: [] }
    }

    const allFeatures = new Set([...plan1.features, ...plan2.features])
    const differences = Array.from(allFeatures).map(feature => ({
      feature,
      plan1: plan1.features.includes(feature),
      plan2: plan2.features.includes(feature)
    }))

    return { plan1, plan2, differences }
  }

  // Private webhook handlers
  private static async handleSuccessfulPayment(data: any): Promise<void> {
    try {
      // Update user subscription in database
      const { plan_id, customer_email } = data.metadata
      
      // Here you would update the user's subscription in your database
      console.log('Payment successful:', {
        plan_id,
        customer_email,
        amount: data.amount,
        reference: data.reference
      })

      // Send confirmation email
      await this.sendPaymentConfirmationEmail(customer_email, plan_id)
    } catch (error) {
      console.error('Error handling successful payment:', error)
    }
  }

  private static async handleSubscriptionCreated(data: any): Promise<void> {
    try {
      console.log('Subscription created:', data)
      
      // Update user subscription status
      // Send welcome email
      // Update usage limits
    } catch (error) {
      console.error('Error handling subscription created:', error)
    }
  }

  private static async handleSubscriptionDisabled(data: any): Promise<void> {
    try {
      console.log('Subscription disabled:', data)
      
      // Update user subscription status
      // Send cancellation email
      // Update usage limits
    } catch (error) {
      console.error('Error handling subscription disabled:', error)
    }
  }

  private static async handleSubscriptionNotRenewed(data: any): Promise<void> {
    try {
      console.log('Subscription not renewed:', data)
      
      // Handle subscription expiration
      // Send renewal reminder
      // Update user status
    } catch (error) {
      console.error('Error handling subscription not renewed:', error)
    }
  }

  private static async handleTransferSuccess(data: any): Promise<void> {
    try {
      console.log('Transfer successful:', data)
      
      // Handle successful transfers
      // Update accounting records
    } catch (error) {
      console.error('Error handling transfer success:', error)
    }
  }

  private static async sendPaymentConfirmationEmail(email: string, planId: string): Promise<void> {
    try {
      const plan = this.getPlanById(planId)
      if (!plan) return

      // Here you would integrate with your email service (SendGrid, etc.)
      console.log('Sending payment confirmation email to:', email, 'for plan:', plan.name)
    } catch (error) {
      console.error('Error sending payment confirmation email:', error)
    }
  }
}
