import { createContext, useContext, ReactNode } from 'react'
import { useAuth } from '../hooks/useAuth'
import { User } from '../lib/supabase'

interface AuthContextType {
  user: User | null
  loading: boolean
  error: string | null
  signIn: (email: string, password: string) => Promise<{ success?: boolean; error?: string }>
  signUp: (email: string, password: string, fullName: string) => Promise<{ success?: boolean; error?: string }>
  signOut: () => Promise<{ success?: boolean; error?: string }>
  resetPassword: (email: string) => Promise<{ success?: boolean; error?: string }>
  updateProfile: (updates: Partial<User>) => Promise<{ success?: boolean; error?: string; user?: User }>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

interface AuthProviderProps {
  children: ReactNode
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const auth = useAuth()

  return (
    <AuthContext.Provider value={auth}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuthContext = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuthContext must be used within an AuthProvider')
  }
  return context
}

