import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Brain, Target, Building2, MessageCircle, CheckCircle } from 'lucide-react'
import { IdeaBuilderModal } from '../components/IdeaBuilderModal'
import { FrameworkAnalysis } from '../components/FrameworkAnalysis'
import { IdeaChatModal } from '../components/IdeaChatModal'
import { ValidationModal } from '../components/ValidationModal'

const Home = () => {
  const [showIdeaBuilderModal, setShowIdeaBuilderModal] = useState(false)
  const [showFrameworkAnalysis, setShowFrameworkAnalysis] = useState(false)
  const [showChatModal, setShowChatModal] = useState(false)
  const [showValidationModal, setShowValidationModal] = useState(false)

  const ideaOfTheDay = {
    id: 'daily-1',
    title: "AI-Powered Local Service Marketplace",
    description: "A platform that connects homeowners with local service providers using AI to match based on location, availability, ratings, and specific needs. The platform uses machine learning to optimize matches and reduce service provider downtime while improving customer satisfaction.",
    category: "AI & Automation",
    difficulty: "Medium",
    marketSize: "$50B",
    timeToMarket: "2-4 months",
    investmentNeeded: "$50K - $250K",
    confidenceScore: 85,
    tags: ["AI", "Marketplace", "Local Services", "Mobile App"]
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
          Discover Your Next<span className="text-blue-600"> Million-Dollar Idea</span>
        </h1>
        <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
          AI-powered business intelligence platform that helps entrepreneurs discover, validate, and develop startup ideas using institutional-grade analysis.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link 
            to="/browse" 
            className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors"
          >
            Browse Ideas
          </Link>
          <Link 
            to="/advanced-tools" 
            className="bg-gray-800 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-900 transition-colors"
          >
            Advanced Tools
          </Link>
        </div>
      </div>

      {/* Idea of the Day */}
      <div className="bg-white rounded-2xl shadow-xl p-8 mb-16">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">💡 Idea of the Day</h2>
          <p className="text-gray-600">Curated and validated by our AI analysis</p>
        </div>
        
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">{ideaOfTheDay.title}</h3>
          <p className="text-gray-700 mb-6">{ideaOfTheDay.description}</p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{ideaOfTheDay.confidenceScore}%</div>
              <div className="text-sm text-gray-600">Confidence</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{ideaOfTheDay.marketSize}</div>
              <div className="text-sm text-gray-600">Market Size</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{ideaOfTheDay.timeToMarket}</div>
              <div className="text-sm text-gray-600">Time to Market</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">{ideaOfTheDay.investmentNeeded}</div>
              <div className="text-sm text-gray-600">Investment</div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-6">
            <button 
              onClick={() => setShowValidationModal(true)}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Validate This Idea
            </button>
            <button 
              onClick={() => setShowChatModal(true)}
              className="bg-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors flex items-center justify-center"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Chat About This Idea
            </button>
          </div>

          {/* Advanced Tools Section */}
          <div className="border-t border-gray-200 pt-6">
            <h4 className="font-semibold text-gray-900 mb-4 flex items-center justify-center">
              <Brain className="w-5 h-5 text-purple-600 mr-2" />
              Advanced Intelligence Tools
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button 
                onClick={() => setShowIdeaBuilderModal(true)}
                className="bg-purple-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-purple-700 transition-colors flex items-center justify-center"
              >
                <Building2 className="w-4 h-4 mr-2" />
                VC-Grade Builder
              </button>
              <button 
                onClick={() => setShowFrameworkAnalysis(true)}
                className="bg-indigo-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-indigo-700 transition-colors flex items-center justify-center"
              >
                <Brain className="w-4 h-4 mr-2" />
                Expert Analysis
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
        <div className="text-center">
          <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Brain className="w-8 h-8 text-blue-600" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">AI-Powered Discovery</h3>
          <p className="text-gray-600">Daily validated startup ideas with detailed analysis</p>
        </div>
        <div className="text-center">
          <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Building2 className="w-8 h-8 text-purple-600" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">VC-Grade Builder</h3>
          <p className="text-gray-600">Generate business plans, financial models, and pitch decks</p>
        </div>
        <div className="text-center">
          <div className="bg-indigo-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Brain className="w-8 h-8 text-indigo-600" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Expert Analysis</h3>
          <p className="text-gray-600">Warren Buffett, VC, and Porter's Five Forces frameworks</p>
        </div>
        <div className="text-center">
          <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Target className="w-8 h-8 text-green-600" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Market Intelligence</h3>
          <p className="text-gray-600">Advanced competitive analysis and market insights</p>
        </div>
      </div>

      {/* CTA */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-center text-white">
        <h2 className="text-3xl font-bold mb-4">Ready to Build Your Future?</h2>
        <p className="text-xl mb-6 opacity-90">
          Join thousands of entrepreneurs using Calyra.ai to discover and validate their next big idea.
        </p>
        <Link 
          to="/pricing" 
          className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors inline-block"
        >
          Get Started Today
        </Link>
      </div>

      {/* Modals */}
      <IdeaBuilderModal
        idea={ideaOfTheDay}
        isOpen={showIdeaBuilderModal}
        onClose={() => setShowIdeaBuilderModal(false)}
      />
      
      <FrameworkAnalysis
        idea={ideaOfTheDay}
        isOpen={showFrameworkAnalysis}
        onClose={() => setShowFrameworkAnalysis(false)}
      />
      
      <IdeaChatModal
        idea={ideaOfTheDay}
        isOpen={showChatModal}
        onClose={() => setShowChatModal(false)}
        ideaType="daily"
      />
      
      <ValidationModal
        idea={ideaOfTheDay}
        isOpen={showValidationModal}
        onClose={() => setShowValidationModal(false)}
      />
    </div>
  )
}

export default Home
