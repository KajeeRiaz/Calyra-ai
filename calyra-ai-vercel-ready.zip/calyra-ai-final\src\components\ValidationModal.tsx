import React, { useState, useEffect } from 'react'
import { CheckCircle, XCircle, AlertTriangle, TrendingUp, Users, DollarSign, Target } from 'lucide-react'

interface ValidationResult {
  overallScore: number
  grade: string
  recommendation: string
  categories: {
    marketValidation: {
      score: number
      status: 'pass' | 'fail' | 'warning'
      analysis: string
      keyPoints: string[]
    }
    competitiveAnalysis: {
      score: number
      status: 'pass' | 'fail' | 'warning'
      analysis: string
      keyPoints: string[]
    }
    businessModel: {
      score: number
      status: 'pass' | 'fail' | 'warning'
      analysis: string
      keyPoints: string[]
    }
    technicalFeasibility: {
      score: number
      status: 'pass' | 'fail' | 'warning'
      analysis: string
      keyPoints: string[]
    }
  }
}

interface ValidationModalProps {
  idea: any
  isOpen: boolean
  onClose: () => void
}

export const ValidationModal: React.FC<ValidationModalProps> = ({ idea, isOpen, onClose }) => {
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)

  const generateValidation = async () => {
    setIsGenerating(true)
    try {
      // Simulate AI validation
      await new Promise(resolve => setTimeout(resolve, 2500))
      
      const result: ValidationResult = {
        overallScore: 82,
        grade: 'A-',
        recommendation: 'Proceed with confidence. This idea shows strong validation across all key areas with manageable risks.',
        categories: {
          marketValidation: {
            score: 85,
            status: 'pass',
            analysis: 'Strong market demand validated through multiple data sources. Target market is clearly defined and accessible.',
            keyPoints: [
              'Market size of $50B+ confirmed',
              'Growing demand trend identified',
              'Clear target customer segments',
              'Strong market timing indicators'
            ]
          },
          competitiveAnalysis: {
            score: 78,
            status: 'pass',
            analysis: 'Competitive landscape is manageable with clear differentiation opportunities. Barriers to entry are developing.',
            keyPoints: [
              'Moderate competitive intensity',
              'Clear differentiation opportunities',
              'Emerging competitive moats',
              'Favorable competitive positioning'
            ]
          },
          businessModel: {
            score: 88,
            status: 'pass',
            analysis: 'Robust business model with multiple revenue streams and strong unit economics potential.',
            keyPoints: [
              'Multiple revenue streams identified',
              'Strong unit economics potential',
              'Scalable business model',
              'Clear path to profitability'
            ]
          },
          technicalFeasibility: {
            score: 75,
            status: 'warning',
            analysis: 'Technically feasible with some complexity considerations. Requires skilled development team.',
            keyPoints: [
              'Core technology is proven',
              'Development complexity is moderate',
              'Requires skilled technical team',
              'Timeline estimates are realistic'
            ]
          }
        }
      }
      
      setValidationResult(result)
    } catch (error) {
      console.error('Error generating validation:', error)
    } finally {
      setIsGenerating(false)
    }
  }

  useEffect(() => {
    if (isOpen && !validationResult) {
      generateValidation()
    }
  }, [isOpen])

  const getStatusIcon = (status: 'pass' | 'fail' | 'warning') => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case 'fail':
        return <XCircle className="w-5 h-5 text-red-500" />
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />
    }
  }

  const getStatusColor = (status: 'pass' | 'fail' | 'warning') => {
    switch (status) {
      case 'pass':
        return 'bg-green-100 text-green-800'
      case 'fail':
        return 'bg-red-100 text-red-800'
      case 'warning':
        return 'bg-yellow-100 text-yellow-800'
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600'
    if (score >= 70) return 'text-yellow-600'
    return 'text-red-600'
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Expert Idea Validation</h2>
              <p className="text-gray-600">Comprehensive analysis for: {idea?.title || 'Your Startup Idea'}</p>
            </div>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto max-h-[70vh]">
          {isGenerating ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Running expert validation analysis...</p>
              </div>
            </div>
          ) : validationResult ? (
            <div className="space-y-6">
              {/* Overall Assessment */}
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-gray-900">Overall Assessment</h3>
                  <div className="flex items-center space-x-4">
                    <div className="text-center">
                      <div className={`text-3xl font-bold ${getScoreColor(validationResult.overallScore)}`}>
                        {validationResult.overallScore}/100
                      </div>
                      <div className="text-sm text-gray-600">Score</div>
                    </div>
                    <span className="px-4 py-2 bg-blue-100 text-blue-800 rounded-full font-semibold">
                      {validationResult.grade}
                    </span>
                  </div>
                </div>
                <p className="text-gray-700">{validationResult.recommendation}</p>
              </div>

              {/* Validation Categories */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Market Validation */}
                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="w-5 h-5 text-blue-600" />
                      <h4 className="font-semibold text-gray-900">Market Validation</h4>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(validationResult.categories.marketValidation.status)}
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(validationResult.categories.marketValidation.status)}`}>
                        {validationResult.categories.marketValidation.status.toUpperCase()}
                      </span>
                    </div>
                  </div>
                  <div className={`text-2xl font-bold ${getScoreColor(validationResult.categories.marketValidation.score)} mb-3`}>
                    {validationResult.categories.marketValidation.score}/100
                  </div>
                  <p className="text-sm text-gray-600 mb-4">{validationResult.categories.marketValidation.analysis}</p>
                  <div className="space-y-2">
                    {validationResult.categories.marketValidation.keyPoints.map((point, index) => (
                      <div key={index} className="flex items-start">
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700">{point}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Competitive Analysis */}
                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      <Users className="w-5 h-5 text-purple-600" />
                      <h4 className="font-semibold text-gray-900">Competitive Analysis</h4>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(validationResult.categories.competitiveAnalysis.status)}
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(validationResult.categories.competitiveAnalysis.status)}`}>
                        {validationResult.categories.competitiveAnalysis.status.toUpperCase()}
                      </span>
                    </div>
                  </div>
                  <div className={`text-2xl font-bold ${getScoreColor(validationResult.categories.competitiveAnalysis.score)} mb-3`}>
                    {validationResult.categories.competitiveAnalysis.score}/100
                  </div>
                  <p className="text-sm text-gray-600 mb-4">{validationResult.categories.competitiveAnalysis.analysis}</p>
                  <div className="space-y-2">
                    {validationResult.categories.competitiveAnalysis.keyPoints.map((point, index) => (
                      <div key={index} className="flex items-start">
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700">{point}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Business Model */}
                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      <DollarSign className="w-5 h-5 text-green-600" />
                      <h4 className="font-semibold text-gray-900">Business Model</h4>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(validationResult.categories.businessModel.status)}
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(validationResult.categories.businessModel.status)}`}>
                        {validationResult.categories.businessModel.status.toUpperCase()}
                      </span>
                    </div>
                  </div>
                  <div className={`text-2xl font-bold ${getScoreColor(validationResult.categories.businessModel.score)} mb-3`}>
                    {validationResult.categories.businessModel.score}/100
                  </div>
                  <p className="text-sm text-gray-600 mb-4">{validationResult.categories.businessModel.analysis}</p>
                  <div className="space-y-2">
                    {validationResult.categories.businessModel.keyPoints.map((point, index) => (
                      <div key={index} className="flex items-start">
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700">{point}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Technical Feasibility */}
                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      <Target className="w-5 h-5 text-orange-600" />
                      <h4 className="font-semibold text-gray-900">Technical Feasibility</h4>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(validationResult.categories.technicalFeasibility.status)}
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(validationResult.categories.technicalFeasibility.status)}`}>
                        {validationResult.categories.technicalFeasibility.status.toUpperCase()}
                      </span>
                    </div>
                  </div>
                  <div className={`text-2xl font-bold ${getScoreColor(validationResult.categories.technicalFeasibility.score)} mb-3`}>
                    {validationResult.categories.technicalFeasibility.score}/100
                  </div>
                  <p className="text-sm text-gray-600 mb-4">{validationResult.categories.technicalFeasibility.analysis}</p>
                  <div className="space-y-2">
                    {validationResult.categories.technicalFeasibility.keyPoints.map((point, index) => (
                      <div key={index} className="flex items-start">
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700">{point}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Next Steps */}
              <div className="bg-gray-50 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-3">Recommended Next Steps</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-start">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mr-3 mt-0.5">
                      <span className="text-blue-600 text-sm font-semibold">1</span>
                    </div>
                    <div>
                      <h5 className="font-medium text-gray-900">Validate Assumptions</h5>
                      <p className="text-sm text-gray-600">Conduct customer interviews and market research</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mr-3 mt-0.5">
                      <span className="text-blue-600 text-sm font-semibold">2</span>
                    </div>
                    <div>
                      <h5 className="font-medium text-gray-900">Build MVP</h5>
                      <p className="text-sm text-gray-600">Develop minimum viable product to test core assumptions</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mr-3 mt-0.5">
                      <span className="text-blue-600 text-sm font-semibold">3</span>
                    </div>
                    <div>
                      <h5 className="font-medium text-gray-900">Secure Funding</h5>
                      <p className="text-sm text-gray-600">Prepare pitch deck and approach investors</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mr-3 mt-0.5">
                      <span className="text-blue-600 text-sm font-semibold">4</span>
                    </div>
                    <div>
                      <h5 className="font-medium text-gray-900">Execute Go-to-Market</h5>
                      <p className="text-sm text-gray-600">Launch marketing campaigns and acquire customers</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  )
}
