import React, { useState } from 'react'
import { TrendingUp, Target, Shield, DollarSign, Brain, CheckCircle } from 'lucide-react'

interface FrameworkAnalysis {
  warrenBuffett: {
    score: number
    grade: string
    analysis: string
    keyPoints: string[]
  }
  vcFramework: {
    score: number
    grade: string
    analysis: string
    keyPoints: string[]
  }
  porterFiveForces: {
    score: number
    grade: string
    analysis: string
    keyPoints: string[]
  }
  blueOceanStrategy: {
    score: number
    grade: string
    analysis: string
    keyPoints: string[]
  }
  overallAssessment: {
    score: number
    grade: string
    recommendation: string
    riskLevel: string
  }
}

interface FrameworkAnalysisProps {
  idea: any
  isOpen: boolean
  onClose: () => void
}

const FRAMEWORK_DESCRIPTIONS = {
  warrenBuffett: {
    title: "Warren Buffett's Investment Framework",
    description: "Analyzes business model, competitive moats, and long-term value creation potential",
    icon: <DollarSign className="w-6 h-6" />
  },
  vcFramework: {
    title: "VC Investment Framework",
    description: "Evaluates market size, team capability, and scalability potential",
    icon: <TrendingUp className="w-6 h-6" />
  },
  porterFiveForces: {
    title: "Porter's Five Forces",
    description: "Assesses competitive landscape and market positioning",
    icon: <Shield className="w-6 h-6" />
  },
  blueOceanStrategy: {
    title: "Blue Ocean Strategy",
    description: "Identifies uncontested market spaces and innovation opportunities",
    icon: <Target className="w-6 h-6" />
  }
}

export const FrameworkAnalysis: React.FC<FrameworkAnalysisProps> = ({ idea, isOpen, onClose }) => {
  const [analysis, setAnalysis] = useState<FrameworkAnalysis | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [activeFramework, setActiveFramework] = useState<keyof typeof FRAMEWORK_DESCRIPTIONS>('warrenBuffett')

  const generateFrameworkAnalysis = async () => {
    setIsGenerating(true)
    try {
      // Simulate AI analysis
      await new Promise(resolve => setTimeout(resolve, 3000))
      setAnalysis(getDemoAnalysis())
    } catch (error) {
      console.error('Error generating analysis:', error)
    } finally {
      setIsGenerating(false)
    }
  }

  const getDemoAnalysis = (): FrameworkAnalysis => ({
    warrenBuffett: {
      score: 78,
      grade: 'B+',
      analysis: 'Strong business model with clear value proposition. Market opportunity is substantial, though competitive landscape requires careful navigation.',
      keyPoints: ['Clear value proposition', 'Large addressable market', 'Competitive moats developing', 'Strong unit economics potential']
    },
    vcFramework: {
      score: 82,
      grade: 'A-',
      analysis: 'Excellent market size and growth potential. Team execution capability is strong, with clear path to scale.',
      keyPoints: ['$50B+ market opportunity', 'Strong team capability', 'Clear scaling path', 'Attractive unit economics']
    },
    porterFiveForces: {
      score: 75,
      grade: 'B',
      analysis: 'Moderate competitive intensity with opportunities for differentiation. Supplier power is low, but buyer power is moderate.',
      keyPoints: ['Moderate competitive rivalry', 'Low supplier power', 'Moderate buyer power', 'Barriers to entry developing']
    },
    blueOceanStrategy: {
      score: 85,
      grade: 'A',
      analysis: 'Significant opportunity to create uncontested market space. Innovation potential is high with clear differentiation opportunities.',
      keyPoints: ['Uncontested market space', 'High innovation potential', 'Clear differentiation', 'Value innovation opportunity']
    },
    overallAssessment: {
      score: 80,
      grade: 'A-',
      recommendation: 'Proceed with confidence. This idea shows strong potential across multiple frameworks with manageable risks.',
      riskLevel: 'Moderate'
    }
  })

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600'
    if (score >= 70) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getGradeColor = (grade: string) => {
    if (grade.includes('A')) return 'bg-green-100 text-green-800'
    if (grade.includes('B')) return 'bg-yellow-100 text-yellow-800'
    return 'bg-red-100 text-red-800'
  }

  React.useEffect(() => {
    if (isOpen && !analysis) {
      generateFrameworkAnalysis()
    }
  }, [isOpen])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Expert Framework Analysis</h2>
              <p className="text-gray-600">Institutional-grade analysis for: {idea?.title || 'Your Idea'}</p>
            </div>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <div className="flex h-[70vh]">
          {/* Framework Navigation */}
          <div className="w-80 border-r border-gray-200 bg-gray-50 p-4">
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Analysis Frameworks</h3>
              
              {/* Overall Assessment */}
              {analysis && (
                <div className="mb-6 p-4 bg-white rounded-lg border">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-gray-900">Overall Assessment</h4>
                    <span className={`px-2 py-1 rounded-full text-sm font-medium ${getGradeColor(analysis.overallAssessment.grade)}`}>
                      {analysis.overallAssessment.grade}
                    </span>
                  </div>
                  <div className={`text-2xl font-bold ${getScoreColor(analysis.overallAssessment.score)}`}>
                    {analysis.overallAssessment.score}/100
                  </div>
                  <p className="text-sm text-gray-600 mt-2">{analysis.overallAssessment.recommendation}</p>
                </div>
              )}

              {/* Framework List */}
              <div className="space-y-2">
                {Object.entries(FRAMEWORK_DESCRIPTIONS).map(([key, framework]) => (
                  <button
                    key={key}
                    onClick={() => setActiveFramework(key as keyof typeof FRAMEWORK_DESCRIPTIONS)}
                    className={`w-full text-left p-3 rounded-lg transition-colors ${
                      activeFramework === key ? 'bg-blue-100 border-blue-300' : 'bg-white hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center mb-2">
                      <div className="text-blue-600 mr-2">{framework.icon}</div>
                      <span className="font-medium text-gray-900">{framework.title}</span>
                    </div>
                    <p className="text-xs text-gray-600">{framework.description}</p>
                    {analysis && (
                      <div className="flex items-center justify-between mt-2">
                        <span className={`text-sm font-semibold ${getScoreColor(analysis[key as keyof FrameworkAnalysis].score)}`}>
                          {analysis[key as keyof FrameworkAnalysis].score}/100
                        </span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getGradeColor(analysis[key as keyof FrameworkAnalysis].grade)}`}>
                          {analysis[key as keyof FrameworkAnalysis].grade}
                        </span>
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Framework Details */}
          <div className="flex-1 p-6 overflow-y-auto">
            {isGenerating ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                  <p className="text-gray-600">Generating expert analysis...</p>
                </div>
              </div>
            ) : analysis ? (
              <div>
                <div className="mb-6">
                  <div className="flex items-center mb-4">
                    <div className="text-blue-600 mr-3">
                      {FRAMEWORK_DESCRIPTIONS[activeFramework].icon}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">
                        {FRAMEWORK_DESCRIPTIONS[activeFramework].title}
                      </h3>
                      <p className="text-gray-600">
                        {FRAMEWORK_DESCRIPTIONS[activeFramework].description}
                      </p>
                    </div>
                  </div>

                  {/* Score and Grade */}
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="text-center">
                      <div className={`text-3xl font-bold ${getScoreColor(analysis[activeFramework].score)}`}>
                        {analysis[activeFramework].score}/100
                      </div>
                      <div className="text-sm text-gray-600">Score</div>
                    </div>
                    <div className="text-center">
                      <span className={`px-4 py-2 rounded-full text-lg font-semibold ${getGradeColor(analysis[activeFramework].grade)}`}>
                        {analysis[activeFramework].grade}
                      </span>
                      <div className="text-sm text-gray-600 mt-1">Grade</div>
                    </div>
                  </div>

                  {/* Analysis */}
                  <div className="bg-gray-50 rounded-lg p-4 mb-6">
                    <h4 className="font-semibold text-gray-900 mb-2">Analysis</h4>
                    <p className="text-gray-700">{analysis[activeFramework].analysis}</p>
                  </div>

                  {/* Key Points */}
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Key Points</h4>
                    <div className="space-y-2">
                      {analysis[activeFramework].keyPoints.map((point, index) => (
                        <div key={index} className="flex items-start">
                          <CheckCircle className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700">{point}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <Brain className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Click "Generate Analysis" to start</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
