import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key'

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
})

// Database types
export interface User {
  id: string
  email: string
  full_name?: string
  avatar_url?: string
  subscription_tier?: 'free' | 'core' | 'growth' | 'enterprise'
  subscription_status?: 'active' | 'canceled' | 'past_due'
  created_at: string
  updated_at: string
}

export interface Idea {
  id: string
  title: string
  description: string
  category: string
  difficulty: string
  market_size: string
  time_to_market: string
  investment_needed: string
  tags: string[]
  confidence_score: number
  created_at: string
  user_id?: string
}

export interface Analysis {
  id: string
  idea_id: string
  framework_type: string
  analysis_data: any
  score: number
  created_at: string
  user_id: string
}

export interface ChatMessage {
  id: string
  idea_id: string
  user_id: string
  message: string
  is_ai: boolean
  created_at: string
}

export interface Validation {
  id: string
  idea_id: string
  user_id: string
  validation_data: any
  overall_score: number
  created_at: string
}

