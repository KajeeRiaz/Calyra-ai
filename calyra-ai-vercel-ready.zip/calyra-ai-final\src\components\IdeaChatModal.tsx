import React, { useState, useRef, useEffect } from 'react'
import { Send, Bot, User, Loader2 } from 'lucide-react'

interface Message {
  id: string
  content: string
  sender: 'user' | 'ai'
  timestamp: Date
}

interface IdeaChatModalProps {
  idea: any
  isOpen: boolean
  onClose: () => void
  ideaType: 'daily' | 'database'
}

export const IdeaChatModal: React.FC<IdeaChatModalProps> = ({ idea, isOpen, onClose, ideaType }) => {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      // Add welcome message
      const welcomeMessage: Message = {
        id: 'welcome',
        content: `Hi! I'm your AI business strategist. I can help you analyze "${idea?.title || 'this startup idea'}" and answer any questions you have about market potential, competitive landscape, business model, or implementation strategy. What would you like to know?`,
        sender: 'ai',
        timestamp: new Date()
      }
      setMessages([welcomeMessage])
    }
  }, [isOpen, idea])

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      sender: 'user',
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    setIsLoading(true)

    try {
      // Simulate AI response
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      const aiResponse = generateAIResponse(inputValue, idea)
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: aiResponse,
        sender: 'ai',
        timestamp: new Date()
      }

      setMessages(prev => [...prev, aiMessage])
    } catch (error) {
      console.error('Error generating response:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const generateAIResponse = (userInput: string, idea: any): string => {
    const input = userInput.toLowerCase()
    
    if (input.includes('market') || input.includes('size')) {
      return `The market for ${idea?.title || 'this idea'} is estimated at ${idea?.marketSize || '$50B'}. This represents a significant opportunity, especially considering the growing demand in the ${idea?.category || 'technology'} sector. The market is expected to grow at a compound annual growth rate of 15-20% over the next 5 years.`
    }
    
    if (input.includes('competition') || input.includes('competitor')) {
      return `The competitive landscape for ${idea?.title || 'this idea'} includes both established players and emerging startups. Key competitors include [Competitor A], [Competitor B], and [Competitor C]. However, there are opportunities for differentiation through ${idea?.category === 'AI & Automation' ? 'advanced AI capabilities' : 'unique value propositions'}.`
    }
    
    if (input.includes('business model') || input.includes('revenue')) {
      return `The recommended business model for ${idea?.title || 'this idea'} would be a SaaS subscription model with tiered pricing. Revenue streams could include: 1) Monthly/annual subscriptions, 2) Enterprise licensing, 3) API access fees, 4) Professional services. The target customer acquisition cost should be kept under $200 with a customer lifetime value of $2,000+.`
    }
    
    if (input.includes('investment') || input.includes('funding')) {
      return `For ${idea?.title || 'this idea'}, you'll likely need ${idea?.investmentNeeded || '$100K - $500K'} in initial funding. This should cover: 1) MVP development (40%), 2) Team hiring (30%), 3) Marketing and customer acquisition (20%), 4) Operational costs (10%). Consider starting with a seed round of $250K to validate the concept.`
    }
    
    if (input.includes('timeline') || input.includes('roadmap')) {
      return `Here's a suggested timeline for ${idea?.title || 'this idea'}: Month 1-2: MVP development and testing, Month 3-4: Beta launch with early adopters, Month 5-6: Full product launch, Month 7-12: Scale and optimize. The key is to validate your assumptions quickly and iterate based on user feedback.`
    }
    
    if (input.includes('risk') || input.includes('challenge')) {
      return `The main risks for ${idea?.title || 'this idea'} include: 1) Market timing - ensure the market is ready, 2) Competition - differentiate clearly, 3) Execution risk - build a strong team, 4) Regulatory changes - stay compliant. Mitigation strategies include thorough market research, strong IP protection, and agile development.`
    }
    
    // Default response
    return `That's an interesting question about ${idea?.title || 'this startup idea'}! Based on my analysis, this idea shows strong potential with a ${idea?.confidenceScore || '85'}% confidence score. The key to success will be execution and market timing. Would you like me to dive deeper into any specific aspect like market analysis, competitive landscape, or business model?`
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Bot className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">AI Business Strategist</h2>
                <p className="text-sm text-gray-600">Analyzing: {idea?.title || 'Your Startup Idea'}</p>
              </div>
            </div>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex items-start space-x-3 max-w-[80%] ${message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.sender === 'user' ? 'bg-blue-600' : 'bg-gray-200'
                }`}>
                  {message.sender === 'user' ? (
                    <User className="w-4 h-4 text-white" />
                  ) : (
                    <Bot className="w-4 h-4 text-gray-600" />
                  )}
                </div>
                <div className={`rounded-lg px-4 py-2 ${
                  message.sender === 'user' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 text-gray-900'
                }`}>
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  <p className={`text-xs mt-1 ${
                    message.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
                  }`}>
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex justify-start">
              <div className="flex items-start space-x-3 max-w-[80%]">
                <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                  <Bot className="w-4 h-4 text-gray-600" />
                </div>
                <div className="bg-gray-100 rounded-lg px-4 py-2">
                  <div className="flex items-center space-x-2">
                    <Loader2 className="w-4 h-4 animate-spin text-gray-500" />
                    <span className="text-sm text-gray-600">AI is thinking...</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-6 border-t border-gray-200">
          <div className="flex space-x-3">
            <div className="flex-1">
              <textarea
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask me anything about this startup idea..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={2}
                disabled={isLoading}
              />
            </div>
            <button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isLoading}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-2">
            Press Enter to send, Shift+Enter for new line
          </p>
        </div>
      </div>
    </div>
  )
}
