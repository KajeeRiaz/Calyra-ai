import { Link } from 'react-router-dom'

const ValidationTools = () => {
  const tools = [
    {
      name: "Market Validation",
      description: "Test your idea's market demand with proven frameworks",
      icon: "📊"
    },
    {
      name: "Competitive Analysis",
      description: "Analyze competitors and identify market gaps",
      icon: "🔍"
    },
    {
      name: "Customer Interviews",
      description: "Structured approach to customer discovery",
      icon: "🎤"
    },
    {
      name: "Financial Modeling",
      description: "Build realistic financial projections",
      icon: "💰"
    }
  ]

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Validation Tools</h1>
        <p className="text-xl text-gray-600">Proven frameworks to validate your startup ideas</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {tools.map((tool, index) => (
          <div key={index} className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
            <div className="text-4xl mb-4">{tool.icon}</div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">{tool.name}</h3>
            <p className="text-gray-600 mb-4">{tool.description}</p>
            <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
              Get Started
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

export default ValidationTools
