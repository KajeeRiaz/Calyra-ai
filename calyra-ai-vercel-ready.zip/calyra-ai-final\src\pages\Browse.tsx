import { useState } from 'react'

const Browse = () => {
  const ideas = [
    {
      id: 1,
      title: "AI-Powered Local Service Marketplace",
      description: "A platform that connects homeowners with local service providers using AI to match based on location, availability, ratings, and specific needs.",
      category: "AI & Automation",
      difficulty: "Medium",
      marketSize: "$50B",
      confidenceScore: 85
    },
    {
      id: 2,
      title: "Sustainable Packaging Solutions",
      description: "Eco-friendly packaging alternatives for e-commerce businesses, reducing environmental impact while maintaining product protection.",
      category: "Sustainability",
      difficulty: "Hard",
      marketSize: "$30B",
      confidenceScore: 78
    },
    {
      id: 3,
      title: "Mental Health AI Companion",
      description: "AI-powered mental health support app that provides 24/7 emotional support, mood tracking, and personalized wellness recommendations.",
      category: "Health & Wellness",
      difficulty: "Hard",
      marketSize: "$25B",
      confidenceScore: 92
    }
  ]

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Browse Startup Ideas</h1>
        <p className="text-xl text-gray-600">Discover validated business opportunities across various industries</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {ideas.map((idea) => (
          <div key={idea.id} className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
            <div className="flex justify-between items-start mb-4">
              <span className="bg-blue-100 text-blue-800 text-sm font-medium px-3 py-1 rounded-full">
                {idea.category}
              </span>
              <span className="text-2xl font-bold text-green-600">{idea.confidenceScore}%</span>
            </div>
            
            <h3 className="text-xl font-bold text-gray-900 mb-3">{idea.title}</h3>
            <p className="text-gray-600 mb-4">{idea.description}</p>
            
            <div className="flex justify-between items-center mb-4">
              <span className="text-sm text-gray-500">Difficulty: {idea.difficulty}</span>
              <span className="text-sm font-semibold text-gray-700">Market: {idea.marketSize}</span>
            </div>
            
            <div className="flex gap-2">
              <button className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
                Analyze
              </button>
              <button className="flex-1 bg-gray-200 text-gray-800 py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors">
                Save
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Browse
