import { useState } from 'react'
import { Building2, Brain, Users, Target, ArrowRight, Star, Zap, TrendingUp, CheckCircle, Clock } from 'lucide-react'
import { IdeaBuilderModal } from '../components/IdeaBuilderModal'
import { FrameworkAnalysis } from '../components/FrameworkAnalysis'

const AdvancedTools = () => {
  const [showIdeaBuilderModal, setShowIdeaBuilderModal] = useState(false)
  const [showFrameworkAnalysis, setShowFrameworkAnalysis] = useState(false)
  const [selectedIdea, setSelectedIdea] = useState<any>(null)

  const demoIdea = {
    id: 'demo-1',
    title: "AI-Powered Local Service Marketplace",
    description: "A platform that connects homeowners with local service providers using AI to match based on location, availability, ratings, and specific needs.",
    category: "AI & Automation",
    difficulty: "Medium",
    marketSize: "$50B",
    timeToMarket: "2-4 months",
    investmentNeeded: "$50K - $250K",
    tags: ["AI", "Marketplace", "Local Services", "Mobile App"],
    confidenceScore: 85
  }

  const advancedTools = [
    {
      id: 'idea-builder',
      title: "VC-Grade Idea Builder",
      description: "Generate institutional-quality business materials including business plans, financial models, pitch decks, and market analysis using proven frameworks and AI-powered insights.",
      icon: <Building2 className="w-8 h-8" />,
      features: [
        "Business Plan Generation",
        "Financial Model Creation",
        "Pitch Deck Development",
        "Market Analysis Reports",
        "Go-to-Market Strategy",
        "Competitive Analysis"
      ],
      color: "purple",
      status: "ready"
    },
    {
      id: 'framework-analysis',
      title: "Expert Framework Analysis",
      description: "Analyze your ideas using Warren Buffett's investment framework, VC evaluation criteria, Porter's Five Forces, and Blue Ocean Strategy for comprehensive market positioning.",
      icon: <Brain className="w-8 h-8" />,
      features: [
        "Warren Buffett Framework",
        "VC Investment Criteria",
        "Porter's Five Forces",
        "Blue Ocean Strategy",
        "Market Matrix Analysis",
        "Value Ladder Assessment"
      ],
      color: "indigo",
      status: "ready"
    },
    {
      id: 'community-intelligence',
      title: "Enhanced Community Intelligence",
      description: "Leverage advanced social listening, community sentiment analysis, and market signal detection to uncover hidden opportunities and validate market demand.",
      icon: <Users className="w-8 h-8" />,
      features: [
        "Social Media Sentiment Analysis",
        "Community Trend Detection",
        "Market Signal Intelligence",
        "Competitor Community Monitoring",
        "Influencer Network Analysis",
        "Real-time Market Pulse"
      ],
      color: "blue",
      status: "coming-soon"
    },
    {
      id: 'founder-assessment',
      title: "Sophisticated Founder Assessment",
      description: "Comprehensive founder-market fit analysis with personality assessment, skill gap analysis, and team building recommendations for optimal startup success.",
      icon: <Target className="w-8 h-8" />,
      features: [
        "Founder-Market Fit Analysis",
        "Personality Assessment",
        "Skill Gap Analysis",
        "Team Building Recommendations",
        "Leadership Development Plan",
        "Success Probability Scoring"
      ],
      color: "green",
      status: "coming-soon"
    }
  ]

  const getColorClasses = (color: string) => {
    const colors = {
      purple: 'bg-purple-600 hover:bg-purple-700',
      indigo: 'bg-indigo-600 hover:bg-indigo-700',
      blue: 'bg-blue-600 hover:bg-blue-700',
      green: 'bg-green-600 hover:bg-green-700'
    }
    return colors[color as keyof typeof colors] || 'bg-gray-600 hover:bg-gray-700'
  }

  const handleToolClick = (tool: any) => {
    if (tool.status === 'ready') {
      if (tool.id === 'idea-builder') {
        setSelectedIdea(demoIdea)
        setShowIdeaBuilderModal(true)
      } else if (tool.id === 'framework-analysis') {
        setSelectedIdea(demoIdea)
        setShowFrameworkAnalysis(true)
      }
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Advanced Intelligence Tools</h1>
        <p className="text-xl text-gray-600">Institutional-grade analysis for serious entrepreneurs</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        {advancedTools.map((tool, index) => (
          <div key={index} className="bg-white rounded-2xl shadow-xl p-8">
            <div className="flex justify-between items-start mb-6">
              <div className="flex items-center">
                <div className={`p-3 rounded-lg mr-4 ${tool.color === 'purple' ? 'bg-purple-100' : tool.color === 'indigo' ? 'bg-indigo-100' : tool.color === 'blue' ? 'bg-blue-100' : 'bg-green-100'}`}>
                  <div className={tool.color === 'purple' ? 'text-purple-600' : tool.color === 'indigo' ? 'text-indigo-600' : tool.color === 'blue' ? 'text-blue-600' : 'text-green-600'}>
                    {tool.icon}
                  </div>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">{tool.title}</h3>
                  <div className="flex items-center mt-1">
                    {tool.status === 'ready' ? (
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    ) : (
                      <Clock className="w-4 h-4 text-yellow-500 mr-2" />
                    )}
                    <span className={`text-sm font-medium ${
                      tool.status === 'ready' ? 'text-green-600' : 'text-yellow-600'
                    }`}>
                      {tool.status === 'ready' ? 'Ready' : 'Coming Soon'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <p className="text-gray-600 mb-6">{tool.description}</p>

            <div className="mb-6">
              <h4 className="font-semibold text-gray-900 mb-3">Key Features:</h4>
              <div className="grid grid-cols-1 gap-2">
                {tool.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-center">
                    <div className={`w-2 h-2 rounded-full mr-3 ${
                      tool.color === 'purple' ? 'bg-purple-500' : 
                      tool.color === 'indigo' ? 'bg-indigo-500' : 
                      tool.color === 'blue' ? 'bg-blue-500' : 'bg-green-500'
                    }`}></div>
                    <span className="text-sm text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            <button 
              onClick={() => handleToolClick(tool)}
              className={`w-full py-3 px-6 rounded-lg font-semibold text-white transition-colors ${
                tool.status === 'ready' 
                  ? getColorClasses(tool.color) 
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
              disabled={tool.status !== 'ready'}
            >
              {tool.status === 'ready' ? (
                <div className="flex items-center justify-center">
                  Try Now
                  <ArrowRight className="w-4 h-4 ml-2" />
                </div>
              ) : (
                <div className="flex items-center justify-center">
                  Coming Soon
                  <Clock className="w-4 h-4 ml-2" />
                </div>
              )}
            </button>
          </div>
        ))}
      </div>

      {/* Enterprise Features */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl p-8 text-center text-white mb-12">
        <h2 className="text-3xl font-bold mb-4">Enterprise Intelligence Suite</h2>
        <p className="text-xl mb-6 opacity-90">
          Advanced features for institutional clients and large teams
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="text-center">
            <div className="bg-white bg-opacity-20 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
              <Star className="w-6 h-6" />
            </div>
            <h3 className="font-semibold mb-2">White-Label Solutions</h3>
            <p className="text-sm opacity-90">Custom branding and integration options</p>
          </div>
          <div className="text-center">
            <div className="bg-white bg-opacity-20 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
              <Zap className="w-6 h-6" />
            </div>
            <h3 className="font-semibold mb-2">API Access</h3>
            <p className="text-sm opacity-90">Programmatic access to all features</p>
          </div>
          <div className="text-center">
            <div className="bg-white bg-opacity-20 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
              <TrendingUp className="w-6 h-6" />
            </div>
            <h3 className="font-semibold mb-2">Advanced Analytics</h3>
            <p className="text-sm opacity-90">Deep insights and reporting capabilities</p>
          </div>
        </div>
        <button className="bg-white text-purple-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors">
          Contact Enterprise Sales
        </button>
      </div>

      {/* Comparison with Competitors */}
      <div className="bg-gray-50 rounded-2xl p-8">
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">Why Calyra.ai Stands Out</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Brain className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Institutional-Grade Analysis</h3>
            <p className="text-gray-600">Warren Buffett, VC, and Porter's frameworks - not just basic validation</p>
          </div>
          <div className="text-center">
            <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Building2 className="w-8 h-8 text-purple-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">VC-Quality Materials</h3>
            <p className="text-gray-600">Generate investor-ready business plans, financial models, and pitch decks</p>
          </div>
          <div className="text-center">
            <div className="bg-indigo-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Target className="w-8 h-8 text-indigo-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Comprehensive Platform</h3>
            <p className="text-gray-600">From idea discovery to execution - everything in one place</p>
          </div>
        </div>
      </div>

      {/* Modals */}
      <IdeaBuilderModal
        idea={selectedIdea}
        isOpen={showIdeaBuilderModal}
        onClose={() => setShowIdeaBuilderModal(false)}
      />
      
      <FrameworkAnalysis
        idea={selectedIdea}
        isOpen={showFrameworkAnalysis}
        onClose={() => setShowFrameworkAnalysis(false)}
      />
    </div>
  )
}

export default AdvancedTools
